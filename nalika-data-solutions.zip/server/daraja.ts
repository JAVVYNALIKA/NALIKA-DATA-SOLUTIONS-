let cachedToken: string | null = null;
let tokenExpiresAt = 0;

interface DarajaConfig {
  env: string;
  baseUrl: string;
  consumerKey: string;
  consumerSecret: string;
  passkey: string;
  storeShortcode: string;
  tillNumber: string;
  callbackUrl: string;
}

export class DarajaError extends Error {
  statusCode: number;
  darajaResponse?: unknown;

  constructor(message: string, statusCode = 500, darajaResponse?: unknown) {
    super(message);
    this.statusCode = statusCode;
    this.darajaResponse = darajaResponse;
  }
}

function getDarajaBaseUrl(): string {
  const env = (process.env.MPESA_ENV || 'production').toLowerCase();
  return env === 'sandbox'
    ? 'https://sandbox.safaricom.co.ke'
    : 'https://api.safaricom.co.ke';
}

function getEatTimestamp(): string {
  // Format YYYYMMDDHHmmss in Africa/Nairobi (EAT, UTC+3)
  const now = new Date();
  const eatTime = new Date(now.getTime() + 3 * 60 * 60 * 1000);
  const yyyy = eatTime.getUTCFullYear();
  const mm = String(eatTime.getUTCMonth() + 1).padStart(2, '0');
  const dd = String(eatTime.getUTCDate()).padStart(2, '0');
  const hh = String(eatTime.getUTCHours()).padStart(2, '0');
  const min = String(eatTime.getUTCMinutes()).padStart(2, '0');
  const ss = String(eatTime.getUTCSeconds()).padStart(2, '0');
  return `${yyyy}${mm}${dd}${hh}${min}${ss}`;
}

export function validateDarajaConfig(): DarajaConfig {
  const env = (process.env.MPESA_ENV || 'production').toLowerCase();
  const consumerKey = (process.env.MPESA_CONSUMER_KEY || '').trim();
  const consumerSecret = (process.env.MPESA_CONSUMER_SECRET || '').trim();
  const passkey = (process.env.MPESA_PASSKEY || '').trim();
  const storeShortcode = (process.env.MPESA_STORE_SHORTCODE || '').trim();
  const tillNumber = (process.env.MPESA_TILL_NUMBER || '9207781').trim();
  const callbackBaseUrl = (process.env.MPESA_CALLBACK_URL || '').trim();
  const callbackSecret = (process.env.MPESA_CALLBACK_SECRET || '').trim();

  const missing: string[] = [];
  if (!consumerKey) missing.push('MPESA_CONSUMER_KEY');
  if (!consumerSecret) missing.push('MPESA_CONSUMER_SECRET');
  if (!passkey) missing.push('MPESA_PASSKEY');
  if (!storeShortcode) missing.push('MPESA_STORE_SHORTCODE');
  if (!tillNumber) missing.push('MPESA_TILL_NUMBER');
  if (!callbackBaseUrl) missing.push('MPESA_CALLBACK_URL');
  if (!callbackSecret) missing.push('MPESA_CALLBACK_SECRET');

  if (missing.length > 0) {
    throw new DarajaError(
      `M-Pesa Daraja credentials are not configured on the server yet (${missing.join(', ')}). Order summary was saved; configure Daraja secrets in Settings to enable live STK Push.`,
      503
    );
  }

  // Explicitly block Daraja Sandbox shortcode 174379 from being used as the real business Till or in production
  if (tillNumber === '174379' || (env === 'production' && storeShortcode === '174379')) {
    throw new DarajaError(
      'Sandbox shortcode 174379 cannot be used as the business Till or in production.',
      500
    );
  }

  return {
    env,
    baseUrl: getDarajaBaseUrl(),
    consumerKey,
    consumerSecret,
    passkey,
    storeShortcode,
    tillNumber,
    callbackUrl: `${callbackBaseUrl.replace(/\/+$/, '')}/${encodeURIComponent(callbackSecret)}`,
  };
}

async function getAccessToken(config: DarajaConfig): Promise<string> {
  const now = Date.now();
  if (cachedToken && now < tokenExpiresAt - 60_000) {
    return cachedToken;
  }

  const credentials = Buffer.from(`${config.consumerKey}:${config.consumerSecret}`).toString('base64');
  const res = await fetch(`${config.baseUrl}/oauth/v1/generate?grant_type=client_credentials`, {
    method: 'GET',
    headers: {
      Authorization: `Basic ${credentials}`,
    },
  });

  const data = (await res.json().catch(() => ({}))) as {
    access_token?: string;
    expires_in?: string | number;
    errorMessage?: string;
  };

  if (!res.ok || !data.access_token) {
    throw new DarajaError(
      data.errorMessage || 'Failed to obtain Safaricom Daraja OAuth access token.',
      502
    );
  }

  const expiresInSec = Number(data.expires_in) || 3599;
  cachedToken = data.access_token;
  tokenExpiresAt = now + expiresInSec * 1000;
  return cachedToken;
}

export async function initiateStkPush(params: {
  mpesaPhone: string;
  amount: number;
  orderRef: string;
}) {
  const config = validateDarajaConfig();
  const token = await getAccessToken(config);
  const timestamp = getEatTimestamp();
  const password = Buffer.from(
    `${config.storeShortcode}${config.passkey}${timestamp}`
  ).toString('base64');

  const payload = {
    BusinessShortCode: config.storeShortcode,
    Password: password,
    Timestamp: timestamp,
    TransactionType: 'CustomerBuyGoodsOnline',
    Amount: Math.round(Number(params.amount)),
    PartyA: params.mpesaPhone,
    PartyB: config.tillNumber,
    PhoneNumber: params.mpesaPhone,
    CallBackURL: config.callbackUrl,
    AccountReference: params.orderRef.slice(0, 12),
    TransactionDesc: 'Nalika Bingwa',
  };

  const res = await fetch(`${config.baseUrl}/mpesa/stkpush/v1/processrequest`, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(payload),
  });

  const data = (await res.json().catch(() => ({}))) as {
    MerchantRequestID?: string;
    CheckoutRequestID?: string;
    ResponseCode?: string;
    ResponseDescription?: string;
    CustomerMessage?: string;
    errorMessage?: string;
  };

  if (!res.ok || data.ResponseCode !== '0') {
    throw new DarajaError(
      data.errorMessage || data.ResponseDescription || 'M-Pesa STK Push request failed.',
      502,
      data
    );
  }

  return {
    MerchantRequestID: data.MerchantRequestID || '',
    CheckoutRequestID: data.CheckoutRequestID || '',
    ResponseDescription: data.ResponseDescription || '',
    CustomerMessage: data.CustomerMessage || 'M-Pesa prompt sent to your phone.',
  };
}

export async function queryStkPushStatus(checkoutRequestId: string) {
  const config = validateDarajaConfig();
  const token = await getAccessToken(config);
  const timestamp = getEatTimestamp();
  const password = Buffer.from(
    `${config.storeShortcode}${config.passkey}${timestamp}`
  ).toString('base64');

  const payload = {
    BusinessShortCode: config.storeShortcode,
    Password: password,
    Timestamp: timestamp,
    CheckoutRequestID: checkoutRequestId,
  };

  const res = await fetch(`${config.baseUrl}/mpesa/stkpushquery/v1/query`, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(payload),
  });

  const data = (await res.json().catch(() => ({}))) as {
    ResultCode?: string | number;
    ResultDesc?: string;
    errorMessage?: string;
  };

  if (!res.ok && data.ResultCode === undefined) {
    throw new DarajaError(
      data.errorMessage || 'Unable to query M-Pesa transaction status right now.',
      502,
      data
    );
  }

  return data;
}
