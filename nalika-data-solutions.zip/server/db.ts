import fs from 'fs';
import path from 'path';
import Database from 'better-sqlite3';

const dataDir = path.resolve(process.cwd(), 'data');
if (!fs.existsSync(dataDir)) {
  fs.mkdirSync(dataDir, { recursive: true });
}

const dbPath = path.join(dataDir, 'nalika.db');
export const db = new Database(dbPath);

db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

db.exec(`
  CREATE TABLE IF NOT EXISTS products (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    slug TEXT NOT NULL UNIQUE,
    category TEXT NOT NULL CHECK(category IN ('DATA DEALS', 'TUNUKIWA DEALS', 'MINUTES DEALS', 'SMS DEALS')),
    name TEXT NOT NULL,
    validity TEXT NOT NULL,
    price INTEGER NOT NULL CHECK(price > 0),
    active INTEGER NOT NULL DEFAULT 1,
    sort_order INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    updated_at TEXT NOT NULL DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS orders (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    order_ref TEXT NOT NULL UNIQUE,
    status_token TEXT NOT NULL,
    recipient_phone TEXT NOT NULL,
    mpesa_phone TEXT NOT NULL,
    total_amount INTEGER NOT NULL CHECK(total_amount > 0),
    payment_status TEXT NOT NULL DEFAULT 'PENDING'
      CHECK(payment_status IN ('PENDING', 'STK_SENT', 'PAID', 'FAILED', 'CANCELLED')),
    order_status TEXT NOT NULL DEFAULT 'AWAITING_PAYMENT'
      CHECK(order_status IN ('AWAITING_PAYMENT', 'PENDING_FULFILMENT', 'FULFILLED', 'CANCELLED')),
    merchant_request_id TEXT,
    checkout_request_id TEXT,
    mpesa_receipt TEXT,
    result_code INTEGER,
    result_desc TEXT,
    admin_notes TEXT DEFAULT '',
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    updated_at TEXT NOT NULL DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS order_items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    order_id INTEGER NOT NULL,
    product_id INTEGER,
    category TEXT NOT NULL,
    product_name TEXT NOT NULL,
    validity TEXT NOT NULL,
    unit_price INTEGER NOT NULL,
    quantity INTEGER NOT NULL CHECK(quantity > 0),
    line_total INTEGER NOT NULL,
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE SET NULL
  );

  CREATE TABLE IF NOT EXISTS admin_credentials (
    id INTEGER PRIMARY KEY CHECK(id = 1),
    username TEXT NOT NULL,
    password_hash TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
  );

  CREATE INDEX IF NOT EXISTS idx_orders_checkout_id ON orders(checkout_request_id);
  CREATE INDEX IF NOT EXISTS idx_orders_ref ON orders(order_ref);
`);

export interface SeedOffer {
  slug: string;
  category: 'DATA DEALS' | 'TUNUKIWA DEALS' | 'MINUTES DEALS' | 'SMS DEALS';
  name: string;
  validity: string;
  price: number;
  sort_order: number;
}

// Official Bingwa Offers Catalogue (exact offers & prices, no invented items)
export const OFFICIAL_CATALOGUE: SeedOffer[] = [
  // 1. DATA DEALS
  { slug: 'data-55-1gb-midnight', category: 'DATA DEALS', name: '1GB', validity: 'Till Midnight', price: 55, sort_order: 1 },
  { slug: 'data-19-1gb-1hr', category: 'DATA DEALS', name: '1GB', validity: '1 Hour', price: 19, sort_order: 2 },
  { slug: 'data-20-250mb-24hr', category: 'DATA DEALS', name: '250MB', validity: '24 Hours', price: 20, sort_order: 3 },
  { slug: 'data-49-400mb-7d', category: 'DATA DEALS', name: '400MB', validity: '7 Days', price: 49, sort_order: 4 },
  { slug: 'data-50-15gb-3hr', category: 'DATA DEALS', name: '1.5GB', validity: '3 Hours', price: 50, sort_order: 5 },
  { slug: 'data-52-15gb-3hr', category: 'DATA DEALS', name: '1.5GB', validity: '3 Hours', price: 52, sort_order: 6 },
  { slug: 'data-99-15gb-24hr', category: 'DATA DEALS', name: '1.5GB', validity: '24 Hours', price: 99, sort_order: 7 },

  // 2. TUNUKIWA DEALS
  { slug: 'tunukiwa-21-1gb-1hr', category: 'TUNUKIWA DEALS', name: '1GB', validity: '1 Hour', price: 21, sort_order: 8 },
  { slug: 'tunukiwa-23-250mb-24hr', category: 'TUNUKIWA DEALS', name: '250MB', validity: '24 Hours', price: 23, sort_order: 9 },
  { slug: 'tunukiwa-52-15gb-3hr', category: 'TUNUKIWA DEALS', name: '1.5GB', validity: '3 Hours', price: 52, sort_order: 10 },
  { slug: 'tunukiwa-53-750mb-50sms-wa-24hr', category: 'TUNUKIWA DEALS', name: '750MB + 50 SMS + Free WhatsApp', validity: '24 Hours', price: 53, sort_order: 11 },
  { slug: 'tunukiwa-110-15gb-24hr', category: 'TUNUKIWA DEALS', name: '1.5GB', validity: '24 Hours', price: 110, sort_order: 12 },

  // 3. MINUTES DEALS
  { slug: 'minutes-22-45min-3hr', category: 'MINUTES DEALS', name: '45 Minutes', validity: '3 Hours', price: 22, sort_order: 13 },
  { slug: 'minutes-51-60min-midnight', category: 'MINUTES DEALS', name: '60 Minutes', validity: 'Till Midnight', price: 51, sort_order: 14 },
  { slug: 'minutes-199-250min-7d', category: 'MINUTES DEALS', name: '250 Minutes', validity: '7 Days', price: 199, sort_order: 15 },

  // 4. SMS DEALS
  { slug: 'sms-5-20sms-24hr', category: 'SMS DEALS', name: '20 SMS', validity: '24 Hours', price: 5, sort_order: 16 },
  { slug: 'sms-10-200sms-24hr', category: 'SMS DEALS', name: '200 SMS', validity: '24 Hours', price: 10, sort_order: 17 },
  { slug: 'sms-30-1000sms-7d', category: 'SMS DEALS', name: '1,000 SMS', validity: '7 Days', price: 30, sort_order: 18 },
  { slug: 'sms-101-1500sms-30d', category: 'SMS DEALS', name: '1,500 SMS', validity: '30 Days', price: 101, sort_order: 19 },
  { slug: 'sms-201-3500sms-30d', category: 'SMS DEALS', name: '3,500 SMS', validity: '30 Days', price: 201, sort_order: 20 },
];

function seedCatalogueIfEmpty() {
  const countRow = db.prepare('SELECT COUNT(*) AS count FROM products').get() as { count: number };
  if (countRow.count === 0) {
    const insert = db.prepare(`
      INSERT INTO products (slug, category, name, validity, price, active, sort_order)
      VALUES (@slug, @category, @name, @validity, @price, 1, @sort_order)
    `);
    const tx = db.transaction((items: SeedOffer[]) => {
      for (const item of items) {
        insert.run(item);
      }
    });
    tx(OFFICIAL_CATALOGUE);
  }
}

seedCatalogueIfEmpty();
