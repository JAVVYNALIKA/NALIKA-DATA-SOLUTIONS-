export const VALID_CATEGORIES = [
  'DATA DEALS',
  'TUNUKIWA DEALS',
  'MINUTES DEALS',
  'SMS DEALS',
] as const;

export function normalizeKenyanPhone(input: unknown): string | null {
  if (typeof input !== 'string') return null;
  const cleaned = input.replace(/[\s\-()]/g, '').trim();

  if (/^\+254(7|1)\d{8}$/.test(cleaned)) {
    return cleaned.slice(1);
  }
  if (/^254(7|1)\d{8}$/.test(cleaned)) {
    return cleaned;
  }
  if (/^0(7|1)\d{8}$/.test(cleaned)) {
    return '254' + cleaned.slice(1);
  }
  if (/^(7|1)\d{8}$/.test(cleaned)) {
    return '254' + cleaned;
  }

  return null;
}

export function isSafaricomPrefix(phone254: string): boolean {
  // Safaricom mobile prefixes: 070x-072x, 0740-0743, 0745-0746, 0748, 0757-0759, 0768-0769, 079x, 0110-0115
  if (!/^254(7|1)\d{8}$/.test(phone254)) return false;
  const local = '0' + phone254.slice(3);
  const p3 = local.slice(0, 3);
  const p4 = local.slice(0, 4);

  if (['070', '071', '072', '079'].includes(p3)) return true;
  if (
    [
      '0740',
      '0741',
      '0742',
      '0743',
      '0745',
      '0746',
      '0748',
      '0757',
      '0758',
      '0759',
      '0768',
      '0769',
      '0110',
      '0111',
      '0112',
      '0113',
      '0114',
      '0115',
    ].includes(p4)
  ) {
    return true;
  }
  return false;
}

export function isValidCategory(category: unknown): boolean {
  return typeof category === 'string' && (VALID_CATEGORIES as readonly string[]).includes(category);
}
