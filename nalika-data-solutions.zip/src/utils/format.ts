import type { ProductCategory } from '../types';

export const CATEGORY_ORDER: ProductCategory[] = [
  'DATA DEALS',
  'TUNUKIWA DEALS',
  'MINUTES DEALS',
  'SMS DEALS',
];

export const CATEGORY_SHORT_LABEL: Record<ProductCategory, string> = {
  'DATA DEALS': 'Data Deals',
  'TUNUKIWA DEALS': 'Tunukiwa Deals',
  'MINUTES DEALS': 'Minutes Deals',
  'SMS DEALS': 'SMS Deals',
};

export function formatKsh(amount: number): string {
  return `KSh ${Number(amount || 0).toLocaleString('en-KE')}`;
}

export function formatLocalPhone(phone: string | null | undefined): string {
  if (!phone) return '';
  if (phone.startsWith('254') && phone.length === 12) {
    return '0' + phone.slice(3);
  }
  return phone;
}
