import React from 'react';
import { X, ShieldCheck } from 'lucide-react';
import type { Order } from '../types';
import { formatKsh, formatLocalPhone } from '../utils/format';

interface OrderSummaryModalProps {
  order: Order | null;
  isSubmitting: boolean;
  error: string | null;
  onClose: () => void;
  onConfirmPay: () => void;
}

export const OrderSummaryModal: React.FC<OrderSummaryModalProps> = ({
  order,
  isSubmitting,
  error,
  onClose,
  onConfirmPay,
}) => {
  if (!order) return null;

  return (
    <div
      className="fixed inset-0 z-50 bg-[#08140E]/75 backdrop-blur-[2px] flex items-center justify-center p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="order-summary-title"
    >
      <div className="bg-white w-full max-w-lg rounded-2xl border border-[#DCE6E0] shadow-2xl max-h-[92vh] overflow-y-auto">
        <div className="flex items-center justify-between px-6 py-4 border-b border-[#E5EDE8]">
          <div>
            <h3 id="order-summary-title" className="text-lg font-bold text-[#091710]">
              Order Summary
            </h3>
            <p className="text-xs text-[#4B6356]">
              NALIKA DATA SOLUTIONS · Till 9207781
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close order summary"
            className="w-9 h-9 inline-flex items-center justify-center rounded-lg text-[#4B6356] hover:bg-[#EDF3EF] hover:text-[#091710] transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-5">
          <div className="space-y-2.5 text-sm">
            <div className="flex justify-between py-1.5 border-b border-[#E5EDE8]">
              <span className="text-[#4B6356]">Order Reference</span>
              <span className="font-mono-tabular font-bold text-[#091710]">
                {order.orderRef}
              </span>
            </div>
            <div className="flex justify-between py-1.5 border-b border-[#E5EDE8]">
              <span className="text-[#4B6356]">Safaricom Receiving Offer</span>
              <span className="font-mono-tabular font-semibold text-[#091710]">
                {formatLocalPhone(order.recipientPhone)}
              </span>
            </div>
            <div className="flex justify-between py-1.5 border-b border-[#E5EDE8]">
              <span className="text-[#4B6356]">M-Pesa Payment Number</span>
              <span className="font-mono-tabular font-semibold text-[#091710]">
                {formatLocalPhone(order.mpesaPhone)}
              </span>
            </div>
          </div>

          <div className="space-y-2">
            <div className="text-xs font-semibold uppercase tracking-wider text-[#4B6356]">
              Items ({order.items.reduce((acc, i) => acc + i.quantity, 0)})
            </div>
            <div className="divide-y divide-[#E5EDE8] border border-[#DCE6E0] rounded-xl bg-[#F8FBF9]">
              {order.items.map((item) => (
                <div
                  key={item.id}
                  className="flex items-center justify-between px-4 py-3 text-sm"
                >
                  <div>
                    <div className="font-semibold text-[#091710]">
                      {item.product_name}
                    </div>
                    <div className="text-xs text-[#4B6356]">
                      {item.category} · {item.validity} · {formatKsh(item.unit_price)} × {item.quantity}
                    </div>
                  </div>
                  <div className="font-mono-tabular font-bold text-[#091710]">
                    {formatKsh(item.line_total)}
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="flex items-center justify-between px-5 py-4 rounded-xl bg-[#08140E] text-white">
            <span className="text-sm text-[#C3D9CC]">Total Payable via M-Pesa</span>
            <span className="font-mono-tabular text-xl font-extrabold text-[#00D673]">
              {formatKsh(order.totalAmount)}
            </span>
          </div>

          <div className="flex items-start gap-2.5 text-xs text-[#2B4637] bg-[#E6F6EE] border border-[#B5E4CA] rounded-xl p-3.5">
            <ShieldCheck className="w-4 h-4 text-[#008A48] shrink-0 mt-0.5" />
            <span>
              An M-Pesa STK Push prompt for{' '}
              <strong className="font-mono-tabular">{formatKsh(order.totalAmount)}</strong>{' '}
              will be sent to{' '}
              <strong className="font-mono-tabular">
                {formatLocalPhone(order.mpesaPhone)}
              </strong>{' '}
              (Buy Goods Till <strong>9207781</strong>). After payment confirmation,
              your order enters fulfilment for{' '}
              <strong className="font-mono-tabular">
                {formatLocalPhone(order.recipientPhone)}
              </strong>
              .
            </span>
          </div>

          {error && (
            <div className="text-xs font-medium text-[#B91C1C] bg-[#FEE2E2] border border-[#FECACA] rounded-xl p-3">
              {error}
            </div>
          )}

          <div className="space-y-2.5 pt-1">
            <button
              type="button"
              onClick={onConfirmPay}
              disabled={isSubmitting}
              className="w-full min-h-[48px] px-5 py-3 rounded-xl bg-[#00A859] hover:bg-[#008748] text-white font-bold text-sm transition-colors disabled:opacity-60 cursor-pointer"
            >
              {isSubmitting
                ? 'Sending M-Pesa STK Push...'
                : 'Confirm & Send M-Pesa STK Push'}
            </button>
            <button
              type="button"
              onClick={onClose}
              disabled={isSubmitting}
              className="w-full min-h-[44px] px-5 py-2.5 rounded-xl bg-[#EDF3EF] hover:bg-[#DCE6E0] text-[#091710] font-semibold text-sm transition-colors cursor-pointer"
            >
              Edit Order Details
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
