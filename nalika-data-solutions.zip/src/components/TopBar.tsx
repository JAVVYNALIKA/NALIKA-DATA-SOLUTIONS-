import React from 'react';

interface TopBarProps {
  currentView: 'storefront' | 'admin';
  onNavigate: (view: 'storefront' | 'admin', hash?: string) => void;
}

export const TopBar: React.FC<TopBarProps> = ({ currentView, onNavigate }) => {
  return (
    <header className="sticky top-0 z-40 bg-[#08140E] text-white border-b border-white/10">
      <div className="max-w-[1280px] mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-8">
        <a
          href="/"
          onClick={(e) => {
            e.preventDefault();
            onNavigate('storefront');
          }}
          className="text-base sm:text-lg font-extrabold tracking-tight text-white whitespace-nowrap shrink-0"
        >
          NALIKA DATA SOLUTIONS
        </a>

        {currentView === 'storefront' ? (
          <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-[#C3D9CC]">
            <a
              href="#offers"
              onClick={(e) => {
                e.preventDefault();
                onNavigate('storefront', 'offers');
              }}
              className="hover:text-white hover:underline underline-offset-4 transition-colors whitespace-nowrap shrink-0"
            >
              Offers
            </a>
            <a
              href="#quick-select"
              onClick={(e) => {
                e.preventDefault();
                onNavigate('storefront', 'quick-select');
              }}
              className="hover:text-white hover:underline underline-offset-4 transition-colors whitespace-nowrap shrink-0"
            >
              Quick Select
            </a>
            <a
              href="#track-order"
              onClick={(e) => {
                e.preventDefault();
                onNavigate('storefront', 'track-order');
              }}
              className="hover:text-white hover:underline underline-offset-4 transition-colors whitespace-nowrap shrink-0"
            >
              Track Order
            </a>
            <a
              href="tel:0798779718"
              className="hover:text-white hover:underline underline-offset-4 transition-colors whitespace-nowrap shrink-0 tabular-nums"
            >
              Care: 0798779718
            </a>
          </nav>
        ) : (
          <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-[#C3D9CC]">
            <span className="whitespace-nowrap shrink-0">
              Admin Console
            </span>
            <span className="text-[#5C7D6B]" aria-hidden="true">
              ·
            </span>
            <span className="font-mono-tabular whitespace-nowrap shrink-0">
              Till 9207781
            </span>
          </nav>
        )}

        <div className="flex items-center shrink-0">
          {currentView === 'storefront' ? (
            <button
              type="button"
              onClick={() => onNavigate('admin')}
              className="px-4 py-2 text-xs sm:text-sm font-semibold text-[#08140E] bg-[#00C86B] hover:bg-[#00A859] hover:text-white rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              Admin Dashboard
            </button>
          ) : (
            <button
              type="button"
              onClick={() => onNavigate('storefront')}
              className="px-4 py-2 text-xs sm:text-sm font-semibold text-white bg-white/10 hover:bg-white/20 border border-white/15 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              Storefront
            </button>
          )}
        </div>
      </div>
    </header>
  );
};
