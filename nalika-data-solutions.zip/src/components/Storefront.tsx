import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  Plus,
  Minus,
  Trash2,
  Search,
  ShoppingBag,
  ArrowRight,
  PhoneCall,
  Layers,
} from 'lucide-react';
import type { Order, Product, ProductCategory } from '../types';
import {
  CATEGORY_ORDER,
  CATEGORY_SHORT_LABEL,
  formatKsh,
} from '../utils/format';
import { OrderSummaryModal } from './OrderSummaryModal';
import { LiveOrderStatus } from './LiveOrderStatus';

const HERO_IMAGE_PATH =
  '/src/assets/images/hero_nalika_connectivity_1795607845943.jpg';

export const Storefront: React.FC = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [loadingProducts, setLoadingProducts] = useState(true);
  const [productsError, setProductsError] = useState<string | null>(null);
  const [heroImgFailed, setHeroImgFailed] = useState(false);

  const [selectedCategory, setSelectedCategory] = useState<
    'ALL' | ProductCategory
  >('ALL');
  const [sortOrder, setSortOrder] = useState<
    'default' | 'price_asc' | 'price_desc'
  >('default');
  const [dropdownProductId, setDropdownProductId] = useState<string>('');
  const [dropdownQty, setDropdownQty] = useState<number>(1);
  const [dropdownError, setDropdownError] = useState<string | null>(null);

  // Cart: productId -> quantity
  const [cart, setCart] = useState<Record<number, number>>({});

  // Checkout phone numbers
  const [recipientPhone, setRecipientPhone] = useState('');
  const [mpesaPhone, setMpesaPhone] = useState('');
  const [sameAsRecipient, setSameAsRecipient] = useState(false);
  const [checkoutError, setCheckoutError] = useState<string | null>(null);
  const [creatingOrder, setCreatingOrder] = useState(false);

  // Modal & STK Push state
  const [pendingOrder, setPendingOrder] = useState<Order | null>(null);
  const [pendingStatusToken, setPendingStatusToken] = useState<string | null>(
    null
  );
  const [sendingStk, setSendingStk] = useState(false);
  const [modalError, setModalError] = useState<string | null>(null);

  // Active live order tracking
  const [activeOrder, setActiveOrder] = useState<Order | null>(null);
  const [activeStatusToken, setActiveStatusToken] = useState<string | null>(
    null
  );
  const pollRef = useRef<number | null>(null);

  // Public Order Tracker
  const [trackRef, setTrackRef] = useState('');
  const [trackPhone, setTrackPhone] = useState('');
  const [trackLoading, setTrackLoading] = useState(false);
  const [trackError, setTrackError] = useState<string | null>(null);
  const [trackedOrder, setTrackedOrder] = useState<Order | null>(null);

  const checkoutSectionRef = useRef<HTMLDivElement | null>(null);
  const activeStatusRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    let mounted = true;
    const load = async () => {
      setLoadingProducts(true);
      setProductsError(null);
      try {
        const res = await fetch('/api/products');
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || 'Failed to load offers.');
        if (mounted) {
          setProducts(data.products || []);
        }
      } catch (err) {
        if (mounted) {
          setProductsError(
            err instanceof Error ? err.message : 'Unable to load offers.'
          );
        }
      } finally {
        if (mounted) setLoadingProducts(false);
      }
    };
    load();
    return () => {
      mounted = false;
    };
  }, []);

  useEffect(() => {
    if (sameAsRecipient) {
      setMpesaPhone(recipientPhone);
    }
  }, [sameAsRecipient, recipientPhone]);

  // Live polling for active STK Push order
  useEffect(() => {
    if (pollRef.current) {
      window.clearInterval(pollRef.current);
      pollRef.current = null;
    }

    if (
      !activeOrder ||
      !activeStatusToken ||
      ['PAID', 'FAILED', 'CANCELLED'].includes(activeOrder.paymentStatus)
    ) {
      return;
    }

    const orderRef = activeOrder.orderRef;
    const token = activeStatusToken;

    pollRef.current = window.setInterval(async () => {
      try {
        const res = await fetch(
          `/api/orders/${encodeURIComponent(orderRef)}/status?token=${encodeURIComponent(token)}`
        );
        if (!res.ok) return;
        const data = await res.json();
        if (data.order) {
          setActiveOrder(data.order);
          if (['PAID', 'FAILED', 'CANCELLED'].includes(data.order.paymentStatus)) {
            if (pollRef.current) {
              window.clearInterval(pollRef.current);
              pollRef.current = null;
            }
          }
        }
      } catch {
        // Ignore transient polling failures
      }
    }, 3500);

    return () => {
      if (pollRef.current) {
        window.clearInterval(pollRef.current);
        pollRef.current = null;
      }
    };
  }, [activeOrder?.orderRef, activeOrder?.paymentStatus, activeStatusToken]);

  const productsById = useMemo(() => {
    const map = new Map<number, Product>();
    for (const p of products) map.set(p.id, p);
    return map;
  }, [products]);

  const cartBreakdown = useMemo(() => {
    const items: Array<{ product: Product; quantity: number; lineTotal: number }> = [];
    let total = 0;
    let totalQty = 0;

    for (const [idStr, qty] of Object.entries(cart)) {
      const id = Number(idStr);
      const product = productsById.get(id);
      if (!product || qty <= 0) continue;
      const lineTotal = product.price * qty;
      total += lineTotal;
      totalQty += qty;
      items.push({ product, quantity: qty, lineTotal });
    }
    return { items, total, totalQty };
  }, [cart, productsById]);

  const addToCart = (productId: number, qty = 1, focusCheckout = false) => {
    setCheckoutError(null);
    setCart((prev) => {
      const current = prev[productId] || 0;
      return {
        ...prev,
        [productId]: Math.min(50, current + qty),
      };
    });

    if (focusCheckout) {
      window.setTimeout(() => {
        checkoutSectionRef.current?.scrollIntoView({
          behavior: 'smooth',
          block: 'start',
        });
      }, 60);
    }
  };

  const updateCartQty = (productId: number, delta: number) => {
    setCart((prev) => {
      const next = (prev[productId] || 0) + delta;
      if (next <= 0) {
        const copy = { ...prev };
        delete copy[productId];
        return copy;
      }
      return { ...prev, [productId]: Math.min(50, next) };
    });
  };

  const handleAddFromDropdown = () => {
    setDropdownError(null);
    const id = Number(dropdownProductId);
    if (!id) {
      setDropdownError('Please choose an offer from the dropdown first.');
      return;
    }
    const safeQty = Math.max(1, Math.min(50, Number(dropdownQty) || 1));
    addToCart(id, safeQty, false);
    setDropdownProductId('');
    setDropdownQty(1);
  };

  const handleReviewOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    setCheckoutError(null);
    setModalError(null);

    if (cartBreakdown.items.length === 0) {
      setCheckoutError('Please add at least one offer to your order.');
      return;
    }

    setCreatingOrder(true);
    try {
      const res = await fetch('/api/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          items: cartBreakdown.items.map((x) => ({
            productId: x.product.id,
            quantity: x.quantity,
          })),
          recipientPhone,
          mpesaPhone: sameAsRecipient ? recipientPhone : mpesaPhone,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        setCheckoutError(data.error || 'Could not generate order summary.');
        return;
      }
      setPendingOrder(data.order);
      setPendingStatusToken(data.statusToken);
    } catch {
      setCheckoutError('Network error while preparing your order summary.');
    } finally {
      setCreatingOrder(false);
    }
  };

  const handleConfirmStkPush = async () => {
    if (!pendingOrder || !pendingStatusToken) return;
    setModalError(null);
    setSendingStk(true);

    try {
      const res = await fetch(
        `/api/orders/${encodeURIComponent(pendingOrder.orderRef)}/stk-push`,
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ statusToken: pendingStatusToken }),
        }
      );
      const data = await res.json();
      if (!res.ok) {
        setModalError(data.error || 'Could not initiate M-Pesa STK Push.');
        return;
      }

      setActiveOrder(data.order);
      setActiveStatusToken(pendingStatusToken);
      setPendingOrder(null);
      setPendingStatusToken(null);
      setCart({});

      window.setTimeout(() => {
        activeStatusRef.current?.scrollIntoView({
          behavior: 'smooth',
          block: 'nearest',
        });
      }, 100);
    } catch {
      setModalError('Network error while sending STK Push request.');
    } finally {
      setSendingStk(false);
    }
  };

  const handleTrackOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    setTrackError(null);
    setTrackedOrder(null);
    setTrackLoading(true);

    try {
      const res = await fetch(
        `/api/orders/track?orderRef=${encodeURIComponent(trackRef.trim())}&phone=${encodeURIComponent(trackPhone.trim())}`
      );
      const data = await res.json();
      if (!res.ok) {
        setTrackError(data.error || 'No matching order found.');
        return;
      }
      setTrackedOrder(data.order);
    } catch {
      setTrackError('Network error while looking up your order.');
    } finally {
      setTrackLoading(false);
    }
  };

  const visibleCategories =
    selectedCategory === 'ALL' ? CATEGORY_ORDER : [selectedCategory];

  const sortedDisplayedOffers = useMemo(() => {
    const filtered =
      selectedCategory === 'ALL'
        ? products
        : products.filter((p) => p.category === selectedCategory);

    if (sortOrder === 'price_asc') {
      return [...filtered].sort(
        (a, b) => a.price - b.price || a.sort_order - b.sort_order
      );
    }
    if (sortOrder === 'price_desc') {
      return [...filtered].sort(
        (a, b) => b.price - a.price || a.sort_order - b.sort_order
      );
    }
    return filtered;
  }, [products, selectedCategory, sortOrder]);

  return (
    <div className="pb-20 lg:pb-12">
      {/* Hero Section */}
      <section className="bg-[#08140E] text-white border-b border-white/10">
        <div className="max-w-[1280px] mx-auto px-4 sm:px-6 py-10 lg:py-14">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
            <div className="lg:col-span-7 flex flex-col justify-center space-y-5">
              <div className="text-xs font-semibold uppercase tracking-[0.14em] text-[#7CE5AD]">
                Official Bingwa Offers Catalogue · M-Pesa STK Push
              </div>
              <h1
                className="font-extrabold tracking-tight text-white leading-[1.12]"
                style={{
                  fontSize: 'clamp(2rem, 3.6vw, 3.25rem)',
                  textWrap: 'balance',
                }}
              >
                Data, Tunukiwa, Minutes &amp; SMS Deals at Official Rates
              </h1>
              <p className="text-[#C3D9CC] text-base leading-relaxed max-w-xl">
                Choose one or multiple Bingwa offers, specify the Safaricom
                number receiving the bundle and your M-Pesa payment number, and
                review your itemized summary before confirming payment to Buy
                Goods Till <strong className="text-white font-mono-tabular">9207781</strong>.
              </p>
              <div className="flex flex-wrap items-center gap-4 pt-1">
                <a
                  href="#offers"
                  className="inline-flex items-center gap-2 px-6 py-3 min-h-[44px] rounded-xl bg-[#00A859] hover:bg-[#008748] text-white font-bold text-sm transition-colors whitespace-nowrap shrink-0"
                >
                  Browse Official Offers
                  <ArrowRight className="w-4 h-4" />
                </a>
                <a
                  href="tel:0798779718"
                  className="inline-flex items-center gap-2 px-5 py-3 min-h-[44px] rounded-xl bg-white/10 hover:bg-white/15 border border-white/15 text-white font-semibold text-sm transition-colors whitespace-nowrap shrink-0"
                >
                  <PhoneCall className="w-4 h-4 text-[#7CE5AD]" />
                  Customer Care: 0798779718
                </a>
              </div>
            </div>

            <div className="lg:col-span-5">
              <div className="relative h-56 sm:h-72 lg:h-full min-h-[240px] rounded-2xl overflow-hidden border border-white/10 bg-[#0F2419]">
                {!heroImgFailed ? (
                  <img
                    src={HERO_IMAGE_PATH}
                    alt="NALIKA DATA SOLUTIONS connectivity architecture"
                    referrerPolicy="no-referrer"
                    onError={() => setHeroImgFailed(true)}
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="w-full h-full flex flex-col items-center justify-center p-6 text-center bg-gradient-to-br from-[#0F2419] via-[#08140E] to-[#123523]">
                    <Layers className="w-10 h-10 text-[#00C86B] mb-3" />
                    <div className="text-lg font-bold text-white">
                      NALIKA DATA SOLUTIONS
                    </div>
                    <div className="text-xs text-[#9CC3AE] mt-1">
                      Official Bingwa Offers · Till 9207781
                    </div>
                  </div>
                )}
                <div className="absolute inset-0 bg-gradient-to-t from-[#08140E]/85 via-[#08140E]/20 to-transparent pointer-events-none" />
                <div className="absolute bottom-4 left-4 right-4 flex items-center justify-between text-xs text-white/90">
                  <span className="font-semibold">Safaricom Daraja STK Push</span>
                  <span className="font-mono-tabular font-bold text-[#7CE5AD]">
                    Till 9207781
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* 4-column Key Info Strip */}
          <div className="mt-8 pt-6 border-t border-white/10 grid grid-cols-2 lg:grid-cols-4 gap-4 text-sm">
            <div>
              <div className="text-xs text-[#8EB39E]">Business Name</div>
              <div className="font-bold text-white mt-0.5">
                NALIKA DATA SOLUTIONS
              </div>
            </div>
            <div>
              <div className="text-xs text-[#8EB39E]">M-Pesa Buy Goods Till</div>
              <div className="font-mono-tabular font-bold text-[#7CE5AD] mt-0.5">
                9207781
              </div>
            </div>
            <div>
              <div className="text-xs text-[#8EB39E]">Official Offers</div>
              <div className="font-mono-tabular font-bold text-white mt-0.5">
                {products.length || 20} Active Deals
              </div>
            </div>
            <div>
              <div className="text-xs text-[#8EB39E]">Customer Care</div>
              <a
                href="tel:0798779718"
                className="font-mono-tabular font-bold text-white hover:text-[#7CE5AD] mt-0.5 inline-block"
              >
                0798779718
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* Main Content Grid */}
      <main className="max-w-[1280px] mx-auto px-4 sm:px-6 mt-8 grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left Column: Dropdown, Filters, Cards, Tracker */}
        <div className="lg:col-span-8 space-y-8">
          {/* Controls Panel */}
          <section
            id="quick-select"
            className="bg-white border border-[#DCE6E0] rounded-2xl p-5 space-y-5"
          >
            <div className="grid grid-cols-1 sm:grid-cols-12 gap-3 items-end">
              <div className="sm:col-span-7">
                <label
                  htmlFor="offer-dropdown"
                  className="block text-xs font-bold uppercase tracking-wider text-[#374B40] mb-1.5"
                >
                  Quick Product Dropdown Selection
                </label>
                <select
                  id="offer-dropdown"
                  value={dropdownProductId}
                  onChange={(e) => setDropdownProductId(e.target.value)}
                  className="w-full min-h-[44px] px-3.5 py-2.5 rounded-xl border border-[#CEDCD4] bg-white text-sm text-[#091710] focus:outline-none focus:ring-2 focus:ring-[#00A859]/30 focus:border-[#00A859]"
                >
                  <option value="">-- Choose an Official Bingwa Offer --</option>
                  {CATEGORY_ORDER.map((cat) => {
                    const catItems = products.filter((p) => p.category === cat);
                    if (catItems.length === 0) return null;
                    return (
                      <optgroup key={cat} label={cat}>
                        {catItems.map((p) => (
                          <option key={p.id} value={p.id}>
                            {formatKsh(p.price)} — {p.name} ({p.validity})
                          </option>
                        ))}
                      </optgroup>
                    );
                  })}
                </select>
              </div>

              <div className="sm:col-span-2">
                <label
                  htmlFor="dropdown-qty"
                  className="block text-xs font-bold uppercase tracking-wider text-[#374B40] mb-1.5"
                >
                  Qty
                </label>
                <input
                  id="dropdown-qty"
                  type="number"
                  min={1}
                  max={50}
                  value={dropdownQty}
                  onChange={(e) =>
                    setDropdownQty(
                      Math.max(1, Math.min(50, Number(e.target.value) || 1))
                    )
                  }
                  className="w-full min-h-[44px] px-3 py-2.5 rounded-xl border border-[#CEDCD4] bg-white text-sm font-mono-tabular text-[#091710] focus:outline-none focus:ring-2 focus:ring-[#00A859]/30 focus:border-[#00A859]"
                />
              </div>

              <div className="sm:col-span-3">
                <button
                  type="button"
                  onClick={handleAddFromDropdown}
                  className="w-full min-h-[44px] inline-flex items-center justify-center gap-1.5 px-4 py-2.5 rounded-xl bg-[#08140E] hover:bg-[#132B1E] text-white text-sm font-semibold transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                >
                  <Plus className="w-4 h-4" />
                  Add Offer
                </button>
              </div>
            </div>

            {dropdownError && (
              <div className="text-xs font-medium text-[#B91C1C] bg-[#FEE2E2] px-3 py-2 rounded-lg">
                {dropdownError}
              </div>
            )}

            {/* Category Filter Tabs & Price Sort Dropdown */}
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
              <div
                className="flex flex-wrap items-center gap-1.5 p-1.5 bg-[#EDF3EF] rounded-xl"
                role="tablist"
                aria-label="Filter offers by category"
              >
                <button
                  type="button"
                  role="tab"
                  aria-selected={selectedCategory === 'ALL'}
                  onClick={() => setSelectedCategory('ALL')}
                  className={`px-3.5 py-2 min-h-[40px] rounded-lg text-xs sm:text-sm font-semibold transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                    selectedCategory === 'ALL'
                      ? 'bg-[#08140E] text-white shadow-sm'
                      : 'text-[#374B40] hover:text-[#091710] hover:bg-white/60'
                  }`}
                >
                  All Offers ({products.length})
                </button>
                {CATEGORY_ORDER.map((cat) => {
                  const count = products.filter((p) => p.category === cat).length;
                  const active = selectedCategory === cat;
                  return (
                    <button
                      key={cat}
                      type="button"
                      role="tab"
                      aria-selected={active}
                      onClick={() => setSelectedCategory(cat)}
                      className={`px-3.5 py-2 min-h-[40px] rounded-lg text-xs sm:text-sm font-semibold transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                        active
                          ? 'bg-[#08140E] text-white shadow-sm'
                          : 'text-[#374B40] hover:text-[#091710] hover:bg-white/60'
                      }`}
                    >
                      {CATEGORY_SHORT_LABEL[cat]} ({count})
                    </button>
                  );
                })}
              </div>

              <div className="flex items-center gap-2 shrink-0">
                <label
                  htmlFor="price-sort-select"
                  className="text-xs font-bold uppercase tracking-wider text-[#374B40] whitespace-nowrap"
                >
                  Sort
                </label>
                <select
                  id="price-sort-select"
                  value={sortOrder}
                  onChange={(e) =>
                    setSortOrder(
                      e.target.value as 'default' | 'price_asc' | 'price_desc'
                    )
                  }
                  className="min-h-[40px] px-3 py-2 rounded-xl border border-[#CEDCD4] bg-white text-xs sm:text-sm font-semibold text-[#091710] focus:outline-none focus:ring-2 focus:ring-[#00A859]/30 focus:border-[#00A859] cursor-pointer"
                >
                  <option value="default">Default Order</option>
                  <option value="price_asc">Price: Lowest to Highest</option>
                  <option value="price_desc">Price: Highest to Lowest</option>
                </select>
              </div>
            </div>
          </section>

          {/* Offers Grid */}
          <section id="offers" className="space-y-8" aria-live="polite">
            {loadingProducts && (
              <div className="bg-white border border-[#DCE6E0] rounded-2xl p-8 text-center text-sm text-[#4B6356]">
                Loading official Bingwa offers catalogue...
              </div>
            )}

            {productsError && (
              <div className="bg-[#FEE2E2] border border-[#FECACA] rounded-2xl p-6 text-sm text-[#B91C1C]">
                {productsError}
              </div>
            )}

            {!loadingProducts &&
              !productsError &&
              sortOrder !== 'default' && (
                <div className="space-y-4">
                  <div className="flex items-baseline justify-between border-b border-[#DCE6E0] pb-2.5">
                    <h2 className="text-lg font-bold text-[#091710] tracking-tight">
                      {selectedCategory === 'ALL'
                        ? 'ALL OFFICIAL OFFERS'
                        : selectedCategory}{' '}
                      ·{' '}
                      {sortOrder === 'price_asc'
                        ? 'Lowest to Highest Price'
                        : 'Highest to Lowest Price'}
                    </h2>
                    <span className="text-xs font-medium text-[#4B6356] tabular-nums">
                      {sortedDisplayedOffers.length} official offer
                      {sortedDisplayedOffers.length === 1 ? '' : 's'}
                    </span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-4">
                    {sortedDisplayedOffers.map((offer) => {
                      const inCartQty = cart[offer.id] || 0;
                      return (
                        <article
                          key={offer.id}
                          className="bg-white border border-[#DCE6E0] hover:border-[#00A859] rounded-xl p-5 flex flex-col justify-between gap-4 transition-all duration-150 hover:-translate-y-0.5 hover:shadow-md"
                        >
                          <div className="space-y-1.5">
                            <div className="text-[11px] font-semibold uppercase tracking-wider text-[#4B6356]">
                              {offer.category}
                            </div>
                            <h3 className="text-lg font-bold text-[#091710] leading-snug">
                              {offer.name}
                            </h3>
                            <div className="text-sm text-[#4B6356]">
                              Validity:{' '}
                              <span className="font-medium text-[#091710]">
                                {offer.validity}
                              </span>
                            </div>
                          </div>

                          <div className="space-y-3 pt-3 border-t border-[#EDF3EF]">
                            <div className="flex items-baseline justify-between">
                              <span className="font-mono-tabular text-2xl font-extrabold text-[#007A41]">
                                {formatKsh(offer.price)}
                              </span>
                              {inCartQty > 0 && (
                                <span className="text-xs font-semibold text-[#007A41] tabular-nums">
                                  {inCartQty} in order
                                </span>
                              )}
                            </div>

                            <div className="flex items-center gap-2">
                              <button
                                type="button"
                                onClick={() => addToCart(offer.id, 1, true)}
                                className="flex-1 min-h-[44px] px-4 py-2 rounded-lg bg-[#00A859] hover:bg-[#008748] text-white text-sm font-bold transition-colors whitespace-nowrap cursor-pointer"
                              >
                                Buy Now
                              </button>
                              <button
                                type="button"
                                onClick={() => addToCart(offer.id, 1, false)}
                                title="Add to multi-offer order"
                                aria-label={`Add ${offer.name} to order`}
                                className="min-w-[44px] min-h-[44px] inline-flex items-center justify-center rounded-lg bg-[#EDF3EF] hover:bg-[#DCE6E0] text-[#091710] font-bold transition-colors cursor-pointer"
                              >
                                <Plus className="w-4 h-4" />
                              </button>
                            </div>
                          </div>
                        </article>
                      );
                    })}
                  </div>
                </div>
              )}

            {!loadingProducts &&
              !productsError &&
              sortOrder === 'default' &&
              visibleCategories.map((cat) => {
                const catOffers = products.filter((p) => p.category === cat);
                if (catOffers.length === 0) return null;

                return (
                  <div key={cat} className="space-y-4">
                    <div className="flex items-baseline justify-between border-b border-[#DCE6E0] pb-2.5">
                      <h2 className="text-lg font-bold text-[#091710] tracking-tight">
                        {cat}
                      </h2>
                      <span className="text-xs font-medium text-[#4B6356] tabular-nums">
                        {catOffers.length} official offer
                        {catOffers.length === 1 ? '' : 's'}
                      </span>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-4">
                      {catOffers.map((offer) => {
                        const inCartQty = cart[offer.id] || 0;
                        return (
                          <article
                            key={offer.id}
                            className="bg-white border border-[#DCE6E0] hover:border-[#00A859] rounded-xl p-5 flex flex-col justify-between gap-4 transition-all duration-150 hover:-translate-y-0.5 hover:shadow-md"
                          >
                            <div className="space-y-1.5">
                              <div className="text-[11px] font-semibold uppercase tracking-wider text-[#4B6356]">
                                {offer.category}
                              </div>
                              <h3 className="text-lg font-bold text-[#091710] leading-snug">
                                {offer.name}
                              </h3>
                              <div className="text-sm text-[#4B6356]">
                                Validity:{' '}
                                <span className="font-medium text-[#091710]">
                                  {offer.validity}
                                </span>
                              </div>
                            </div>

                            <div className="space-y-3 pt-3 border-t border-[#EDF3EF]">
                              <div className="flex items-baseline justify-between">
                                <span className="font-mono-tabular text-2xl font-extrabold text-[#007A41]">
                                  {formatKsh(offer.price)}
                                </span>
                                {inCartQty > 0 && (
                                  <span className="text-xs font-semibold text-[#007A41] tabular-nums">
                                    {inCartQty} in order
                                  </span>
                                )}
                              </div>

                              <div className="flex items-center gap-2">
                                <button
                                  type="button"
                                  onClick={() => addToCart(offer.id, 1, true)}
                                  className="flex-1 min-h-[44px] px-4 py-2 rounded-lg bg-[#00A859] hover:bg-[#008748] text-white text-sm font-bold transition-colors whitespace-nowrap cursor-pointer"
                                >
                                  Buy Now
                                </button>
                                <button
                                  type="button"
                                  onClick={() => addToCart(offer.id, 1, false)}
                                  title="Add to multi-offer order"
                                  aria-label={`Add ${offer.name} to order`}
                                  className="min-w-[44px] min-h-[44px] inline-flex items-center justify-center rounded-lg bg-[#EDF3EF] hover:bg-[#DCE6E0] text-[#091710] font-bold transition-colors cursor-pointer"
                                >
                                  <Plus className="w-4 h-4" />
                                </button>
                              </div>
                            </div>
                          </article>
                        );
                      })}
                    </div>
                  </div>
                );
              })}
          </section>

          {/* Public Order Tracker */}
          <section
            id="track-order"
            className="bg-white border border-[#DCE6E0] rounded-2xl p-6 space-y-4"
          >
            <div>
              <h2 className="text-lg font-bold text-[#091710]">
                Track Existing Order &amp; Payment Status
              </h2>
              <p className="text-xs text-[#4B6356] mt-0.5">
                Enter your Order Reference and either the receiving or M-Pesa phone
                number used during checkout.
              </p>
            </div>

            <form
              onSubmit={handleTrackOrder}
              className="grid grid-cols-1 sm:grid-cols-12 gap-3 items-end"
            >
              <div className="sm:col-span-5">
                <label
                  htmlFor="track-ref"
                  className="block text-xs font-bold text-[#374B40] mb-1"
                >
                  Order Reference
                </label>
                <input
                  id="track-ref"
                  type="text"
                  required
                  value={trackRef}
                  onChange={(e) => setTrackRef(e.target.value)}
                  placeholder="e.g. NLK..."
                  className="w-full min-h-[44px] px-3.5 py-2 rounded-xl border border-[#CEDCD4] text-sm font-mono-tabular focus:outline-none focus:ring-2 focus:ring-[#00A859]/30 focus:border-[#00A859]"
                />
              </div>
              <div className="sm:col-span-4">
                <label
                  htmlFor="track-phone"
                  className="block text-xs font-bold text-[#374B40] mb-1"
                >
                  Receiving or M-Pesa No.
                </label>
                <input
                  id="track-phone"
                  type="tel"
                  required
                  value={trackPhone}
                  onChange={(e) => setTrackPhone(e.target.value)}
                  placeholder="07XXXXXXXX"
                  className="w-full min-h-[44px] px-3.5 py-2 rounded-xl border border-[#CEDCD4] text-sm font-mono-tabular focus:outline-none focus:ring-2 focus:ring-[#00A859]/30 focus:border-[#00A859]"
                />
              </div>
              <div className="sm:col-span-3">
                <button
                  type="submit"
                  disabled={trackLoading}
                  className="w-full min-h-[44px] inline-flex items-center justify-center gap-1.5 px-4 py-2 rounded-xl bg-[#08140E] hover:bg-[#132B1E] text-white text-sm font-semibold transition-colors whitespace-nowrap cursor-pointer disabled:opacity-60"
                >
                  <Search className="w-4 h-4" />
                  {trackLoading ? 'Checking...' : 'Check Status'}
                </button>
              </div>
            </form>

            {trackError && (
              <div className="text-xs font-medium text-[#B91C1C] bg-[#FEE2E2] px-3.5 py-2.5 rounded-xl">
                {trackError}
              </div>
            )}

            {trackedOrder && (
              <div className="pt-3 border-t border-[#E5EDE8]">
                <LiveOrderStatus order={trackedOrder} />
              </div>
            )}
          </section>
        </div>

        {/* Right Column: Sticky Order Cart & Checkout */}
        <aside
          ref={checkoutSectionRef}
          id="checkout-panel"
          className="lg:col-span-4 lg:sticky lg:top-20 space-y-6"
        >
          <div className="bg-white border border-[#DCE6E0] rounded-2xl p-5 sm:p-6 space-y-5">
            <div className="flex items-center justify-between border-b border-[#E5EDE8] pb-3">
              <div className="flex items-center gap-2">
                <ShoppingBag className="w-5 h-5 text-[#008A48]" />
                <h2 className="text-lg font-bold text-[#091710]">
                  Your Order Cart
                </h2>
              </div>
              {cartBreakdown.items.length > 0 && (
                <button
                  type="button"
                  onClick={() => setCart({})}
                  className="inline-flex items-center gap-1 text-xs font-semibold text-[#4B6356] hover:text-[#B91C1C] transition-colors cursor-pointer"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  Clear
                </button>
              )}
            </div>

            {cartBreakdown.items.length === 0 ? (
              <p className="text-sm text-[#4B6356] py-3">
                No offers selected yet. Click <strong>Buy Now</strong> or{' '}
                <strong>+</strong> on any offer to build a single or multi-offer
                order.
              </p>
            ) : (
              <div className="space-y-2.5 max-h-72 overflow-y-auto pr-1">
                {cartBreakdown.items.map(({ product, quantity, lineTotal }) => (
                  <div
                    key={product.id}
                    className="flex items-center justify-between gap-3 p-3 rounded-xl bg-[#F6FAF7] border border-[#DCE6E0]"
                  >
                    <div className="min-w-0">
                      <div className="text-sm font-bold text-[#091710] truncate">
                        {product.name} ({product.validity})
                      </div>
                      <div className="text-xs text-[#4B6356] font-mono-tabular">
                        {formatKsh(product.price)} × {quantity} ={' '}
                        <strong className="text-[#091710]">
                          {formatKsh(lineTotal)}
                        </strong>
                      </div>
                    </div>

                    <div className="flex items-center gap-1.5 shrink-0">
                      <button
                        type="button"
                        onClick={() => updateCartQty(product.id, -1)}
                        aria-label={`Decrease quantity for ${product.name}`}
                        className="w-8 h-8 inline-flex items-center justify-center rounded-lg border border-[#CEDCD4] bg-white hover:bg-[#EDF3EF] text-[#091710] cursor-pointer"
                      >
                        <Minus className="w-3.5 h-3.5" />
                      </button>
                      <span className="w-6 text-center text-sm font-mono-tabular font-bold">
                        {quantity}
                      </span>
                      <button
                        type="button"
                        onClick={() => updateCartQty(product.id, 1)}
                        aria-label={`Increase quantity for ${product.name}`}
                        className="w-8 h-8 inline-flex items-center justify-center rounded-lg border border-[#CEDCD4] bg-white hover:bg-[#EDF3EF] text-[#091710] cursor-pointer"
                      >
                        <Plus className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}

            <div className="flex items-center justify-between px-4 py-3.5 rounded-xl bg-[#08140E] text-white">
              <span className="text-sm text-[#C3D9CC]">Order Total</span>
              <span className="font-mono-tabular text-xl font-extrabold text-[#00D673]">
                {formatKsh(cartBreakdown.total)}
              </span>
            </div>

            <form onSubmit={handleReviewOrder} className="space-y-4">
              <div>
                <label
                  htmlFor="recipient-phone"
                  className="block text-xs font-bold text-[#091710] mb-1"
                >
                  Safaricom Number Receiving Offer *
                </label>
                <input
                  id="recipient-phone"
                  type="tel"
                  inputMode="numeric"
                  required
                  value={recipientPhone}
                  onChange={(e) => setRecipientPhone(e.target.value)}
                  placeholder="e.g. 0712345678"
                  className="w-full min-h-[44px] px-3.5 py-2.5 rounded-xl border border-[#CEDCD4] text-sm font-mono-tabular focus:outline-none focus:ring-2 focus:ring-[#00A859]/30 focus:border-[#00A859]"
                />
                <p className="text-[11px] text-[#4B6356] mt-1">
                  The Safaricom line that will receive the selected Bingwa offers.
                </p>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label
                    htmlFor="mpesa-phone"
                    className="block text-xs font-bold text-[#091710]"
                  >
                    M-Pesa Payment Number *
                  </label>
                  <label className="inline-flex items-center gap-1.5 text-[11px] font-medium text-[#374B40] cursor-pointer">
                    <input
                      type="checkbox"
                      checked={sameAsRecipient}
                      onChange={(e) => setSameAsRecipient(e.target.checked)}
                      className="rounded border-[#CEDCD4] text-[#00A859] focus:ring-[#00A859]"
                    />
                    Same as receiving
                  </label>
                </div>
                <input
                  id="mpesa-phone"
                  type="tel"
                  inputMode="numeric"
                  required
                  disabled={sameAsRecipient}
                  value={sameAsRecipient ? recipientPhone : mpesaPhone}
                  onChange={(e) => setMpesaPhone(e.target.value)}
                  placeholder="e.g. 0798779718"
                  className="w-full min-h-[44px] px-3.5 py-2.5 rounded-xl border border-[#CEDCD4] text-sm font-mono-tabular disabled:bg-[#F3F7F4] disabled:text-[#4B6356] focus:outline-none focus:ring-2 focus:ring-[#00A859]/30 focus:border-[#00A859]"
                />
                <p className="text-[11px] text-[#4B6356] mt-1">
                  Receives the Safaricom M-Pesa STK Push prompt (Till 9207781).
                </p>
              </div>

              <div className="text-xs text-[#2B4637] bg-[#E6F6EE] border border-[#B5E4CA] rounded-xl p-3 leading-relaxed">
                Payments go to <strong>NALIKA DATA SOLUTIONS</strong> (Till{' '}
                <strong className="font-mono-tabular">9207781</strong>). Once M-Pesa
                confirms payment, your order is queued for fulfilment. Need help?
                Call <strong className="font-mono-tabular">0798779718</strong>.
              </div>

              {checkoutError && (
                <div className="text-xs font-medium text-[#B91C1C] bg-[#FEE2E2] border border-[#FECACA] rounded-xl p-3">
                  {checkoutError}
                </div>
              )}

              <button
                type="submit"
                disabled={creatingOrder}
                className="w-full min-h-[48px] px-5 py-3 rounded-xl bg-[#00A859] hover:bg-[#008748] text-white font-bold text-sm transition-colors disabled:opacity-60 cursor-pointer"
              >
                {creatingOrder
                  ? 'Generating Order Summary...'
                  : 'Review Order Summary & Pay'}
              </button>
            </form>
          </div>

          {/* Live Order & Payment Status Panel */}
          {activeOrder && (
            <div
              ref={activeStatusRef}
              className="bg-white border border-[#DCE6E0] rounded-2xl p-5 sm:p-6 space-y-4"
            >
              <h3 className="text-base font-bold text-[#091710] border-b border-[#E5EDE8] pb-2.5">
                Live Order &amp; Payment Status
              </h3>
              <LiveOrderStatus
                order={activeOrder}
                statusToken={activeStatusToken}
                onOrderUpdated={(updated) => setActiveOrder(updated)}
              />
            </div>
          )}
        </aside>
      </main>

      {/* Mobile Compact Bottom Cart Bar (<= 56px, well under 15% mobile viewport cap) */}
      {cartBreakdown.totalQty > 0 && (
        <div className="lg:hidden fixed bottom-0 left-0 right-0 z-40 h-14 bg-[#08140E] text-white border-t border-white/15 px-4 flex items-center justify-between gap-3">
          <div className="min-w-0">
            <div className="text-[11px] text-[#9CC3AE] truncate tabular-nums">
              {cartBreakdown.totalQty} offer{cartBreakdown.totalQty === 1 ? '' : 's'}
            </div>
            <div className="text-sm font-mono-tabular font-bold text-[#00D673]">
              {formatKsh(cartBreakdown.total)}
            </div>
          </div>
          <button
            type="button"
            onClick={() =>
              checkoutSectionRef.current?.scrollIntoView({
                behavior: 'smooth',
                block: 'start',
              })
            }
            className="px-4 py-2 min-h-[40px] rounded-lg bg-[#00A859] hover:bg-[#008748] text-white text-xs font-bold whitespace-nowrap shrink-0 cursor-pointer"
          >
            Checkout
          </button>
        </div>
      )}

      {/* Footer */}
      <footer className="mt-16 bg-[#08140E] text-[#9CC3AE] border-t border-white/10">
        <div className="max-w-[1280px] mx-auto px-4 sm:px-6 py-8 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 text-sm">
          <div>
            <span className="font-bold text-white">NALIKA DATA SOLUTIONS</span>
            <span className="mx-2" aria-hidden="true">
              ·
            </span>
            <span className="font-mono-tabular">Buy Goods Till: 9207781</span>
          </div>
          <div>
            Customer Care:{' '}
            <a
              href="tel:0798779718"
              className="font-mono-tabular font-bold text-[#7CE5AD] hover:underline"
            >
              0798779718
            </a>
          </div>
        </div>
      </footer>

      {/* Order Summary Modal */}
      <OrderSummaryModal
        order={pendingOrder}
        isSubmitting={sendingStk}
        error={modalError}
        onClose={() => {
          if (!sendingStk) {
            setPendingOrder(null);
            setModalError(null);
          }
        }}
        onConfirmPay={handleConfirmStkPush}
      />
    </div>
  );
};
