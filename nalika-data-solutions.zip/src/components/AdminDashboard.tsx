import React, { useCallback, useEffect, useState } from 'react';
import {
  LogOut,
  Plus,
  RefreshCw,
  Save,
  Trash2,
  Search,
  Lock,
} from 'lucide-react';
import type {
  AdminOrderSummary,
  Order,
  OrderStatus,
  Product,
  ProductCategory,
} from '../types';
import { CATEGORY_ORDER, formatKsh, formatLocalPhone } from '../utils/format';

export const AdminDashboard: React.FC = () => {
  // Token kept strictly in React memory (never localStorage/sessionStorage)
  const [token, setToken] = useState<string | null>(null);
  const [username, setUsername] = useState<string>('');
  const [needsSetup, setNeedsSetup] = useState<boolean>(false);
  const [checkingAuth, setCheckingAuth] = useState<boolean>(true);

  // Auth form
  const [formUser, setFormUser] = useState('admin');
  const [formPass, setFormPass] = useState('');
  const [authError, setAuthError] = useState<string | null>(null);
  const [authSubmitting, setAuthSubmitting] = useState(false);

  // Tabs
  const [activeTab, setActiveTab] = useState<'orders' | 'products'>('orders');

  // Orders state
  const [orders, setOrders] = useState<Order[]>([]);
  const [summary, setSummary] = useState<AdminOrderSummary>({
    totalOrders: 0,
    paidPendingFulfilment: 0,
    fulfilledCount: 0,
    totalRevenue: 0,
  });
  const [statusFilter, setStatusFilter] = useState('ALL');
  const [searchQuery, setSearchQuery] = useState('');
  const [loadingOrders, setLoadingOrders] = useState(false);
  const [orderFeedback, setOrderFeedback] = useState<string | null>(null);
  const [editedOrderStatuses, setEditedOrderStatuses] = useState<
    Record<number, OrderStatus>
  >({});
  const [editedOrderNotes, setEditedOrderNotes] = useState<
    Record<number, string>
  >({});

  // Products state
  const [products, setProducts] = useState<Product[]>([]);
  const [editedProducts, setEditedProducts] = useState<
    Record<
      number,
      {
        category: ProductCategory;
        name: string;
        validity: string;
        price: number;
        active: boolean;
      }
    >
  >({});
  const [newCategory, setNewCategory] = useState<ProductCategory>('DATA DEALS');
  const [newName, setNewName] = useState('');
  const [newValidity, setNewValidity] = useState('');
  const [newPrice, setNewPrice] = useState('');
  const [productFeedback, setProductFeedback] = useState<{
    type: 'success' | 'error';
    text: string;
  } | null>(null);

  useEffect(() => {
    let mounted = true;
    const init = async () => {
      try {
        const res = await fetch('/api/admin/status');
        const data = await res.json();
        if (mounted) {
          setNeedsSetup(Boolean(data.needsSetup));
        }
      } catch {
        // Ignore
      } finally {
        if (mounted) setCheckingAuth(false);
      }
    };
    init();
    return () => {
      mounted = false;
    };
  }, []);

  const authHeaders = useCallback(
    (extra?: Record<string, string>) => ({
      Authorization: `Bearer ${token}`,
      ...extra,
    }),
    [token]
  );

  const loadOrders = useCallback(async () => {
    if (!token) return;
    setLoadingOrders(true);
    try {
      const res = await fetch(
        `/api/admin/orders?status=${encodeURIComponent(statusFilter)}&q=${encodeURIComponent(searchQuery)}`,
        { headers: authHeaders() }
      );
      if (res.status === 401) {
        setToken(null);
        return;
      }
      const data = await res.json();
      const loadedOrders: Order[] = data.orders || [];
      setOrders(loadedOrders);
      if (data.summary) setSummary(data.summary);

      const statusMap: Record<number, OrderStatus> = {};
      const notesMap: Record<number, string> = {};
      for (const o of loadedOrders) {
        statusMap[o.id] = o.orderStatus;
        notesMap[o.id] = o.adminNotes || '';
      }
      setEditedOrderStatuses(statusMap);
      setEditedOrderNotes(notesMap);
    } finally {
      setLoadingOrders(false);
    }
  }, [token, statusFilter, searchQuery, authHeaders]);

  const loadProducts = useCallback(async () => {
    if (!token) return;
    const res = await fetch('/api/admin/products', { headers: authHeaders() });
    if (res.status === 401) {
      setToken(null);
      return;
    }
    const data = await res.json();
    const list: Product[] = data.products || [];
    setProducts(list);

    const draft: Record<
      number,
      {
        category: ProductCategory;
        name: string;
        validity: string;
        price: number;
        active: boolean;
      }
    > = {};
    for (const p of list) {
      draft[p.id] = {
        category: p.category,
        name: p.name,
        validity: p.validity,
        price: p.price,
        active: p.active !== 0,
      };
    }
    setEditedProducts(draft);
  }, [token, authHeaders]);

  useEffect(() => {
    if (token) {
      loadOrders();
    }
  }, [token, loadOrders]);

  useEffect(() => {
    if (token) {
      loadProducts();
    }
  }, [token, loadProducts]);

  const handleAuthSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError(null);
    setAuthSubmitting(true);

    try {
      const endpoint = needsSetup ? '/api/admin/setup' : '/api/admin/login';
      const res = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username: formUser.trim(), password: formPass }),
      });
      const data = await res.json();
      if (!res.ok) {
        setAuthError(data.error || 'Authentication failed.');
        return;
      }
      setToken(data.token);
      setUsername(data.username || formUser.trim());
      setNeedsSetup(false);
      setFormPass('');
    } catch {
      setAuthError('Network error while authenticating.');
    } finally {
      setAuthSubmitting(false);
    }
  };

  const handleSaveOrder = async (orderId: number) => {
    if (!token) return;
    setOrderFeedback(null);
    const res = await fetch(`/api/admin/orders/${orderId}`, {
      method: 'PATCH',
      headers: authHeaders({ 'Content-Type': 'application/json' }),
      body: JSON.stringify({
        orderStatus: editedOrderStatuses[orderId],
        adminNotes: editedOrderNotes[orderId] ?? '',
      }),
    });
    if (res.ok) {
      setOrderFeedback(`Order #${orderId} updated.`);
      await loadOrders();
    }
  };

  const handleQueryDarajaOrder = async (orderId: number) => {
    if (!token) return;
    setOrderFeedback(null);
    const res = await fetch(`/api/admin/orders/${orderId}/query-payment`, {
      method: 'POST',
      headers: authHeaders(),
    });
    const data = await res.json();
    if (!res.ok) {
      setOrderFeedback(data.error || 'Could not query Daraja.');
    } else {
      setOrderFeedback('Daraja status synced.');
    }
    await loadOrders();
  };

  const handleAddProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!token) return;
    setProductFeedback(null);

    const res = await fetch('/api/admin/products', {
      method: 'POST',
      headers: authHeaders({ 'Content-Type': 'application/json' }),
      body: JSON.stringify({
        category: newCategory,
        name: newName.trim(),
        validity: newValidity.trim(),
        price: Number(newPrice),
      }),
    });
    const data = await res.json();
    if (!res.ok) {
      setProductFeedback({
        type: 'error',
        text: data.error || 'Failed to add offer.',
      });
      return;
    }

    setNewName('');
    setNewValidity('');
    setNewPrice('');
    setProductFeedback({
      type: 'success',
      text: 'Offer added to catalogue.',
    });
    await loadProducts();
  };

  const handleSaveProduct = async (id: number) => {
    if (!token) return;
    const draft = editedProducts[id];
    if (!draft) return;
    setProductFeedback(null);

    const res = await fetch(`/api/admin/products/${id}`, {
      method: 'PUT',
      headers: authHeaders({ 'Content-Type': 'application/json' }),
      body: JSON.stringify(draft),
    });
    const data = await res.json();
    if (!res.ok) {
      setProductFeedback({
        type: 'error',
        text: data.error || 'Failed to update offer.',
      });
      return;
    }
    setProductFeedback({
      type: 'success',
      text: `Updated "${draft.name}".`,
    });
    await loadProducts();
  };

  const handleDeleteProduct = async (id: number, name: string) => {
    if (!token) return;
    setProductFeedback(null);
    const res = await fetch(`/api/admin/products/${id}`, {
      method: 'DELETE',
      headers: authHeaders(),
    });
    if (res.ok) {
      setProductFeedback({
        type: 'success',
        text: `Removed "${name}" from catalogue.`,
      });
      await loadProducts();
    }
  };

  if (checkingAuth) {
    return (
      <div className="max-w-md mx-auto mt-16 bg-white border border-[#DCE6E0] rounded-2xl p-8 text-center text-sm text-[#4B6356]">
        Checking admin status...
      </div>
    );
  }

  if (!token) {
    return (
      <div className="max-w-md mx-auto px-4 mt-12">
        <div className="bg-white border border-[#DCE6E0] rounded-2xl p-6 sm:p-8 space-y-5">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#E6F6EE] text-[#008A48] flex items-center justify-center">
              <Lock className="w-5 h-5" />
            </div>
            <div>
              <h1 className="text-lg font-bold text-[#091710]">
                {needsSetup ? 'Create Admin Account' : 'Admin Sign In'}
              </h1>
              <p className="text-xs text-[#4B6356]">
                NALIKA DATA SOLUTIONS · Till 9207781
              </p>
            </div>
          </div>

          {needsSetup && (
            <p className="text-xs text-[#2B4637] bg-[#E6F6EE] border border-[#B5E4CA] rounded-xl p-3 leading-relaxed">
              First-run setup: create an admin username and password (at least 8
              characters) to manage offers and orders. You can also set{' '}
              <code className="font-mono-tabular">ADMIN_PASSWORD</code> in
              environment secrets at any time.
            </p>
          )}

          <form onSubmit={handleAuthSubmit} className="space-y-4">
            <div>
              <label
                htmlFor="admin-username"
                className="block text-xs font-bold text-[#091710] mb-1"
              >
                Username
              </label>
              <input
                id="admin-username"
                type="text"
                required
                autoComplete="username"
                value={formUser}
                onChange={(e) => setFormUser(e.target.value)}
                className="w-full min-h-[44px] px-3.5 py-2.5 rounded-xl border border-[#CEDCD4] text-sm focus:outline-none focus:ring-2 focus:ring-[#00A859]/30 focus:border-[#00A859]"
              />
            </div>

            <div>
              <label
                htmlFor="admin-password"
                className="block text-xs font-bold text-[#091710] mb-1"
              >
                Password
              </label>
              <input
                id="admin-password"
                type="password"
                required
                minLength={needsSetup ? 8 : 1}
                autoComplete={needsSetup ? 'new-password' : 'current-password'}
                value={formPass}
                onChange={(e) => setFormPass(e.target.value)}
                className="w-full min-h-[44px] px-3.5 py-2.5 rounded-xl border border-[#CEDCD4] text-sm focus:outline-none focus:ring-2 focus:ring-[#00A859]/30 focus:border-[#00A859]"
              />
            </div>

            {authError && (
              <div className="text-xs font-medium text-[#B91C1C] bg-[#FEE2E2] px-3.5 py-2.5 rounded-xl">
                {authError}
              </div>
            )}

            <button
              type="submit"
              disabled={authSubmitting}
              className="w-full min-h-[46px] px-5 py-2.5 rounded-xl bg-[#00A859] hover:bg-[#008748] text-white font-bold text-sm transition-colors cursor-pointer disabled:opacity-60"
            >
              {authSubmitting
                ? 'Please wait...'
                : needsSetup
                  ? 'Save Admin Credentials & Enter'
                  : 'Sign In'}
            </button>
          </form>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-[1280px] mx-auto px-4 sm:px-6 py-8 space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-extrabold text-[#091710]">
            Operations &amp; Catalogue Dashboard
          </h1>
          <p className="text-xs text-[#4B6356] mt-0.5">
            Signed in as <strong>{username}</strong> · Official Bingwa Offers
            &amp; Daraja M-Pesa Orders
          </p>
        </div>

        <button
          type="button"
          onClick={() => setToken(null)}
          className="inline-flex items-center gap-2 px-4 py-2 min-h-[40px] rounded-xl border border-[#CEDCD4] bg-white hover:bg-[#EDF3EF] text-sm font-semibold text-[#091710] transition-colors cursor-pointer"
        >
          <LogOut className="w-4 h-4" />
          Sign Out
        </button>
      </div>

      {/* KPI Strip */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white border border-[#DCE6E0] rounded-xl p-4">
          <div className="text-xs font-medium text-[#4B6356]">Total Orders</div>
          <div className="mt-1.5 text-2xl font-extrabold font-mono-tabular text-[#091710]">
            {summary.totalOrders}
          </div>
        </div>
        <div className="bg-white border border-[#DCE6E0] rounded-xl p-4">
          <div className="text-xs font-medium text-[#4B6356]">
            Paid · Pending Fulfilment
          </div>
          <div className="mt-1.5 text-2xl font-extrabold font-mono-tabular text-[#92400E]">
            {summary.paidPendingFulfilment}
          </div>
        </div>
        <div className="bg-white border border-[#DCE6E0] rounded-xl p-4">
          <div className="text-xs font-medium text-[#4B6356]">
            Fulfilled Orders
          </div>
          <div className="mt-1.5 text-2xl font-extrabold font-mono-tabular text-[#007A41]">
            {summary.fulfilledCount}
          </div>
        </div>
        <div className="bg-white border border-[#DCE6E0] rounded-xl p-4">
          <div className="text-xs font-medium text-[#4B6356]">
            Confirmed M-Pesa Revenue
          </div>
          <div className="mt-1.5 text-2xl font-extrabold font-mono-tabular text-[#007A41]">
            {formatKsh(summary.totalRevenue)}
          </div>
        </div>
      </div>

      {/* Section Switcher */}
      <div className="inline-flex items-center gap-1 p-1 bg-[#EDF3EF] rounded-xl">
        <button
          type="button"
          onClick={() => setActiveTab('orders')}
          className={`px-4 py-2 min-h-[40px] rounded-lg text-sm font-semibold transition-colors whitespace-nowrap cursor-pointer ${
            activeTab === 'orders'
              ? 'bg-[#08140E] text-white'
              : 'text-[#374B40] hover:text-[#091710]'
          }`}
        >
          Orders &amp; Payments
        </button>
        <button
          type="button"
          onClick={() => setActiveTab('products')}
          className={`px-4 py-2 min-h-[40px] rounded-lg text-sm font-semibold transition-colors whitespace-nowrap cursor-pointer ${
            activeTab === 'products'
              ? 'bg-[#08140E] text-white'
              : 'text-[#374B40] hover:text-[#091710]'
          }`}
        >
          Offers Catalogue ({products.length})
        </button>
      </div>

      {/* Orders Tab */}
      {activeTab === 'orders' && (
        <section className="bg-white border border-[#DCE6E0] rounded-2xl p-5 space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="flex flex-wrap items-center gap-2.5">
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                aria-label="Filter orders by status"
                className="min-h-[40px] px-3 py-2 rounded-xl border border-[#CEDCD4] bg-white text-sm text-[#091710]"
              >
                <option value="ALL">All Orders</option>
                <option value="PENDING_FULFILMENT">
                  Paid — Pending Fulfilment
                </option>
                <option value="FULFILLED">Fulfilled</option>
                <option value="AWAITING_PAYMENT">Awaiting Payment</option>
                <option value="PAID">Payment Confirmed</option>
                <option value="FAILED">Payment Failed</option>
                <option value="CANCELLED">Cancelled</option>
              </select>

              <div className="relative">
                <Search className="w-4 h-4 text-[#4B6356] absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="search"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search Ref, Phone, Receipt..."
                  className="min-h-[40px] pl-9 pr-3 py-2 rounded-xl border border-[#CEDCD4] text-sm w-60"
                />
              </div>
            </div>

            <button
              type="button"
              onClick={loadOrders}
              disabled={loadingOrders}
              className="inline-flex items-center gap-1.5 px-4 py-2 min-h-[40px] rounded-xl bg-[#08140E] text-white text-sm font-semibold hover:bg-[#132B1E] transition-colors cursor-pointer"
            >
              <RefreshCw
                className={`w-4 h-4 ${loadingOrders ? 'animate-spin' : ''}`}
              />
              Refresh
            </button>
          </div>

          {orderFeedback && (
            <div className="text-xs font-medium text-[#007A41] bg-[#E6F6EE] px-3.5 py-2 rounded-lg">
              {orderFeedback}
            </div>
          )}

          {orders.length === 0 ? (
            <div className="py-10 text-center text-sm text-[#4B6356]">
              No orders match the current filter.
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-sm">
                <thead>
                  <tr className="border-b border-[#DCE6E0] bg-[#F6FAF7] text-xs uppercase text-[#4B6356]">
                    <th className="py-3 px-3">Order Ref</th>
                    <th className="py-3 px-3">Offers</th>
                    <th className="py-3 px-3">Receiving</th>
                    <th className="py-3 px-3">M-Pesa No.</th>
                    <th className="py-3 px-3 text-right">Total</th>
                    <th className="py-3 px-3">Payment</th>
                    <th className="py-3 px-3">Fulfilment &amp; Notes</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#EDF3EF]">
                  {orders.map((o) => (
                    <tr key={o.id} className="hover:bg-[#FAFDFB] align-top">
                      <td className="py-3 px-3 whitespace-nowrap">
                        <div className="font-mono-tabular font-bold text-[#091710]">
                          {o.orderRef}
                        </div>
                        <div className="text-[11px] font-mono-tabular text-[#4B6356]">
                          {o.createdAt}
                        </div>
                        {o.mpesaReceipt && (
                          <div className="text-xs font-mono-tabular font-semibold text-[#007A41] mt-1">
                            {o.mpesaReceipt}
                          </div>
                        )}
                      </td>
                      <td className="py-3 px-3 text-xs space-y-1 min-w-[180px]">
                        {o.items.map((it) => (
                          <div key={it.id}>
                            <span className="font-semibold text-[#091710]">
                              {it.product_name}
                            </span>{' '}
                            <span className="text-[#4B6356]">
                              ({it.validity}) × {it.quantity}
                            </span>
                          </div>
                        ))}
                      </td>
                      <td className="py-3 px-3 font-mono-tabular font-semibold whitespace-nowrap">
                        {formatLocalPhone(o.recipientPhone)}
                      </td>
                      <td className="py-3 px-3 font-mono-tabular whitespace-nowrap text-[#4B6356]">
                        {formatLocalPhone(o.mpesaPhone)}
                      </td>
                      <td className="py-3 px-3 font-mono-tabular font-bold text-right whitespace-nowrap">
                        {formatKsh(o.totalAmount)}
                      </td>
                      <td className="py-3 px-3 text-xs">
                        <div className="font-semibold text-[#091710]">
                          {o.paymentStatus.replace(/_/g, ' ')}
                        </div>
                        {o.resultDesc && (
                          <div className="text-[11px] text-[#4B6356] max-w-[180px] mt-0.5">
                            {o.resultDesc}
                          </div>
                        )}
                        {o.checkoutRequestId && o.paymentStatus !== 'PAID' && (
                          <button
                            type="button"
                            onClick={() => handleQueryDarajaOrder(o.id)}
                            className="mt-2 px-2.5 py-1 rounded-md bg-[#EDF3EF] hover:bg-[#DCE6E0] text-[#091710] font-semibold cursor-pointer"
                          >
                            Query Daraja
                          </button>
                        )}
                      </td>
                      <td className="py-3 px-3 min-w-[210px] space-y-2">
                        <select
                          value={editedOrderStatuses[o.id] ?? o.orderStatus}
                          onChange={(e) =>
                            setEditedOrderStatuses((prev) => ({
                              ...prev,
                              [o.id]: e.target.value as OrderStatus,
                            }))
                          }
                          className="w-full min-h-[36px] px-2.5 py-1 rounded-lg border border-[#CEDCD4] text-xs font-semibold"
                        >
                          <option value="AWAITING_PAYMENT">
                            Awaiting Payment
                          </option>
                          <option value="PENDING_FULFILMENT">
                            Pending Fulfilment
                          </option>
                          <option value="FULFILLED">Fulfilled</option>
                          <option value="CANCELLED">Cancelled</option>
                        </select>
                        <input
                          type="text"
                          value={editedOrderNotes[o.id] ?? ''}
                          onChange={(e) =>
                            setEditedOrderNotes((prev) => ({
                              ...prev,
                              [o.id]: e.target.value,
                            }))
                          }
                          placeholder="Fulfilment notes..."
                          className="w-full min-h-[34px] px-2.5 py-1 rounded-lg border border-[#CEDCD4] text-xs"
                        />
                        <button
                          type="button"
                          onClick={() => handleSaveOrder(o.id)}
                          className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg bg-[#00A859] hover:bg-[#008748] text-white text-xs font-semibold cursor-pointer"
                        >
                          <Save className="w-3.5 h-3.5" />
                          Save
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </section>
      )}

      {/* Products Tab */}
      {activeTab === 'products' && (
        <section className="bg-white border border-[#DCE6E0] rounded-2xl p-5 space-y-6">
          <form
            onSubmit={handleAddProduct}
            className="grid grid-cols-1 sm:grid-cols-12 gap-3 items-end pb-5 border-b border-[#E5EDE8]"
          >
            <div className="sm:col-span-3">
              <label className="block text-xs font-bold text-[#374B40] mb-1">
                Category
              </label>
              <select
                value={newCategory}
                onChange={(e) =>
                  setNewCategory(e.target.value as ProductCategory)
                }
                className="w-full min-h-[42px] px-3 py-2 rounded-xl border border-[#CEDCD4] text-sm"
              >
                {CATEGORY_ORDER.map((cat) => (
                  <option key={cat} value={cat}>
                    {cat}
                  </option>
                ))}
              </select>
            </div>
            <div className="sm:col-span-3">
              <label className="block text-xs font-bold text-[#374B40] mb-1">
                Offer Name
              </label>
              <input
                type="text"
                required
                value={newName}
                onChange={(e) => setNewName(e.target.value)}
                placeholder="e.g. 1GB"
                className="w-full min-h-[42px] px-3 py-2 rounded-xl border border-[#CEDCD4] text-sm"
              />
            </div>
            <div className="sm:col-span-2">
              <label className="block text-xs font-bold text-[#374B40] mb-1">
                Validity
              </label>
              <input
                type="text"
                required
                value={newValidity}
                onChange={(e) => setNewValidity(e.target.value)}
                placeholder="e.g. 24 Hours"
                className="w-full min-h-[42px] px-3 py-2 rounded-xl border border-[#CEDCD4] text-sm"
              />
            </div>
            <div className="sm:col-span-2">
              <label className="block text-xs font-bold text-[#374B40] mb-1">
                Price (KSh)
              </label>
              <input
                type="number"
                min={1}
                required
                value={newPrice}
                onChange={(e) => setNewPrice(e.target.value)}
                className="w-full min-h-[42px] px-3 py-2 rounded-xl border border-[#CEDCD4] text-sm font-mono-tabular"
              />
            </div>
            <div className="sm:col-span-2">
              <button
                type="submit"
                className="w-full min-h-[42px] inline-flex items-center justify-center gap-1.5 px-4 py-2 rounded-xl bg-[#00A859] hover:bg-[#008748] text-white text-sm font-bold cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                Add Offer
              </button>
            </div>
          </form>

          {productFeedback && (
            <div
              className={`text-xs font-medium px-3.5 py-2.5 rounded-xl ${
                productFeedback.type === 'error'
                  ? 'bg-[#FEE2E2] text-[#B91C1C]'
                  : 'bg-[#E6F6EE] text-[#007A41]'
              }`}
            >
              {productFeedback.text}
            </div>
          )}

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-sm">
              <thead>
                <tr className="border-b border-[#DCE6E0] bg-[#F6FAF7] text-xs uppercase text-[#4B6356]">
                  <th className="py-3 px-3">Category</th>
                  <th className="py-3 px-3">Offer Name</th>
                  <th className="py-3 px-3">Validity</th>
                  <th className="py-3 px-3">Price (KSh)</th>
                  <th className="py-3 px-3">Visibility</th>
                  <th className="py-3 px-3">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#EDF3EF]">
                {products.map((p) => {
                  const draft = editedProducts[p.id];
                  if (!draft) return null;
                  return (
                    <tr key={p.id}>
                      <td className="py-2.5 px-3">
                        <select
                          value={draft.category}
                          onChange={(e) =>
                            setEditedProducts((prev) => ({
                              ...prev,
                              [p.id]: {
                                ...prev[p.id],
                                category: e.target.value as ProductCategory,
                              },
                            }))
                          }
                          className="min-h-[38px] px-2.5 py-1 rounded-lg border border-[#CEDCD4] text-xs font-semibold"
                        >
                          {CATEGORY_ORDER.map((cat) => (
                            <option key={cat} value={cat}>
                              {cat}
                            </option>
                          ))}
                        </select>
                      </td>
                      <td className="py-2.5 px-3">
                        <input
                          type="text"
                          value={draft.name}
                          onChange={(e) =>
                            setEditedProducts((prev) => ({
                              ...prev,
                              [p.id]: { ...prev[p.id], name: e.target.value },
                            }))
                          }
                          className="w-full min-h-[38px] px-2.5 py-1 rounded-lg border border-[#CEDCD4] text-sm"
                        />
                      </td>
                      <td className="py-2.5 px-3">
                        <input
                          type="text"
                          value={draft.validity}
                          onChange={(e) =>
                            setEditedProducts((prev) => ({
                              ...prev,
                              [p.id]: {
                                ...prev[p.id],
                                validity: e.target.value,
                              },
                            }))
                          }
                          className="w-full min-h-[38px] px-2.5 py-1 rounded-lg border border-[#CEDCD4] text-sm"
                        />
                      </td>
                      <td className="py-2.5 px-3">
                        <input
                          type="number"
                          min={1}
                          value={draft.price}
                          onChange={(e) =>
                            setEditedProducts((prev) => ({
                              ...prev,
                              [p.id]: {
                                ...prev[p.id],
                                price: Number(e.target.value) || 1,
                              },
                            }))
                          }
                          className="w-24 min-h-[38px] px-2.5 py-1 rounded-lg border border-[#CEDCD4] text-sm font-mono-tabular"
                        />
                      </td>
                      <td className="py-2.5 px-3">
                        <select
                          value={draft.active ? '1' : '0'}
                          onChange={(e) =>
                            setEditedProducts((prev) => ({
                              ...prev,
                              [p.id]: {
                                ...prev[p.id],
                                active: e.target.value === '1',
                              },
                            }))
                          }
                          className="min-h-[38px] px-2.5 py-1 rounded-lg border border-[#CEDCD4] text-xs font-semibold"
                        >
                          <option value="1">Active</option>
                          <option value="0">Hidden</option>
                        </select>
                      </td>
                      <td className="py-2.5 px-3">
                        <div className="flex items-center gap-2">
                          <button
                            type="button"
                            onClick={() => handleSaveProduct(p.id)}
                            className="inline-flex items-center gap-1 px-3 py-1.5 min-h-[36px] rounded-lg bg-[#00A859] hover:bg-[#008748] text-white text-xs font-semibold cursor-pointer"
                          >
                            <Save className="w-3.5 h-3.5" />
                            Save
                          </button>
                          <button
                            type="button"
                            onClick={() => handleDeleteProduct(p.id, p.name)}
                            aria-label={`Delete ${p.name}`}
                            className="inline-flex items-center justify-center p-2 min-h-[36px] rounded-lg bg-[#FEE2E2] hover:bg-[#FECACA] text-[#B91C1C] cursor-pointer"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </section>
      )}
    </div>
  );
};
