import React, { useState } from 'react';
import { CheckCircle2, Clock, AlertCircle, XCircle, RefreshCw } from 'lucide-react';
import type { Order } from '../types';
import { formatKsh, formatLocalPhone } from '../utils/format';

interface LiveOrderStatusProps {
  order: Order;
  statusToken?: string | null;
  onOrderUpdated?: (updated: Order) => void;
}

function StatusTag({ value }: { value: string }) {
  const normalized = value.toUpperCase();
  const label = normalized.replace(/_/g, ' ');

  if (normalized === 'PAID' || normalized === 'FULFILLED') {
    return (
      <span className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#007A41] bg-[#E6F6EE] px-2.5 py-1 rounded-md">
        <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />
        {label}
      </span>
    );
  }
  if (normalized === 'FAILED' || normalized === 'CANCELLED') {
    return (
      <span className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#B91C1C] bg-[#FEE2E2] px-2.5 py-1 rounded-md">
        <XCircle className="w-3.5 h-3.5 shrink-0" />
        {label}
      </span>
    );
  }
  if (normalized === 'STK_SENT') {
    return (
      <span className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#92400E] bg-[#FEF3C7] px-2.5 py-1 rounded-md">
        <Clock className="w-3.5 h-3.5 shrink-0" />
        {label}
      </span>
    );
  }
  return (
    <span className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#374B40] bg-[#EDF3EF] px-2.5 py-1 rounded-md">
      <AlertCircle className="w-3.5 h-3.5 shrink-0" />
      {label}
    </span>
  );
}

export const LiveOrderStatus: React.FC<LiveOrderStatusProps> = ({
  order,
  statusToken,
  onOrderUpdated,
}) => {
  const [checking, setChecking] = useState(false);
  const [queryError, setQueryError] = useState<string | null>(null);

  const handleQueryDaraja = async () => {
    if (!statusToken) return;
    setChecking(true);
    setQueryError(null);
    try {
      const res = await fetch(
        `/api/orders/${encodeURIComponent(order.orderRef)}/query-payment`,
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ statusToken }),
        }
      );
      const data = await res.json();
      if (!res.ok) {
        setQueryError(data.error || 'Could not query Daraja right now.');
        return;
      }
      if (data.order && onOrderUpdated) {
        onOrderUpdated(data.order);
      }
    } catch {
      setQueryError('Network error while checking M-Pesa status.');
    } finally {
      setChecking(false);
    }
  };

  return (
    <div className="space-y-3 text-sm">
      <div className="flex items-center justify-between py-2 border-b border-[#E5EDE8]">
        <span className="text-[#4B6356]">Order Reference</span>
        <span className="font-mono-tabular font-bold text-[#091710]">
          {order.orderRef}
        </span>
      </div>

      <div className="flex items-center justify-between py-2 border-b border-[#E5EDE8]">
        <span className="text-[#4B6356]">Payment Status</span>
        <StatusTag value={order.paymentStatus} />
      </div>

      <div className="flex items-center justify-between py-2 border-b border-[#E5EDE8]">
        <span className="text-[#4B6356]">Order Fulfilment</span>
        <StatusTag value={order.orderStatus} />
      </div>

      <div className="flex items-center justify-between py-2 border-b border-[#E5EDE8]">
        <span className="text-[#4B6356]">Receiving Safaricom</span>
        <span className="font-mono-tabular font-semibold text-[#091710]">
          {formatLocalPhone(order.recipientPhone)}
        </span>
      </div>

      <div className="flex items-center justify-between py-2 border-b border-[#E5EDE8]">
        <span className="text-[#4B6356]">M-Pesa Payment No.</span>
        <span className="font-mono-tabular font-semibold text-[#091710]">
          {formatLocalPhone(order.mpesaPhone)}
        </span>
      </div>

      <div className="flex items-center justify-between py-2 border-b border-[#E5EDE8]">
        <span className="text-[#4B6356]">Total Amount</span>
        <span className="font-mono-tabular font-bold text-[#007A41]">
          {formatKsh(order.totalAmount)}
        </span>
      </div>

      {order.mpesaReceipt && (
        <div className="flex items-center justify-between py-2 border-b border-[#E5EDE8]">
          <span className="text-[#4B6356]">M-Pesa Receipt</span>
          <span className="font-mono-tabular font-bold text-[#091710]">
            {order.mpesaReceipt}
          </span>
        </div>
      )}

      {order.resultDesc && (
        <p className="text-xs text-[#4B6356] bg-[#F6FAF7] border border-[#DCE6E0] rounded-lg px-3 py-2">
          {order.resultDesc}
        </p>
      )}

      <div className="pt-1 space-y-1.5">
        <div className="text-xs font-semibold uppercase tracking-wider text-[#4B6356]">
          Selected Offers
        </div>
        {order.items.map((item) => (
          <div
            key={item.id}
            className="flex items-center justify-between text-xs py-1 text-[#091710]"
          >
            <span>
              {item.product_name} ({item.validity}) × {item.quantity}
            </span>
            <span className="font-mono-tabular font-semibold">
              {formatKsh(item.line_total)}
            </span>
          </div>
        ))}
      </div>

      {order.paymentStatus === 'PAID' &&
        order.orderStatus === 'PENDING_FULFILMENT' &&
        !order.autoFulfillEnabled && (
          <div className="bg-[#E6F6EE] border border-[#B5E4CA] text-[#0A3D23] rounded-lg p-3 text-xs leading-relaxed">
            Payment confirmed for Till <strong>9207781</strong>. Your Bingwa
            offer is queued for fulfilment to{' '}
            <strong className="font-mono-tabular">
              {formatLocalPhone(order.recipientPhone)}
            </strong>
            . Customer Care:{' '}
            <a href="tel:0798779718" className="font-semibold underline">
              0798779718
            </a>
            .
          </div>
        )}

      {statusToken &&
        order.checkoutRequestId &&
        (order.paymentStatus === 'STK_SENT' || order.paymentStatus === 'PENDING') && (
          <div className="pt-2 space-y-2">
            <button
              type="button"
              onClick={handleQueryDaraja}
              disabled={checking}
              className="w-full min-h-[44px] inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg bg-[#08140E] hover:bg-[#132B1E] text-white text-xs font-semibold transition-colors disabled:opacity-60 cursor-pointer"
            >
              <RefreshCw className={`w-4 h-4 ${checking ? 'animate-spin' : ''}`} />
              {checking ? 'Checking Safaricom Daraja...' : 'Verify M-Pesa Payment Status'}
            </button>
            {queryError && (
              <div className="text-xs text-[#B91C1C] bg-[#FEE2E2] px-3 py-2 rounded-lg">
                {queryError}
              </div>
            )}
          </div>
        )}
    </div>
  );
};
