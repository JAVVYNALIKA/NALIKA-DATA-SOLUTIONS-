/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useEffect, useState } from 'react';
import { TopBar } from './components/TopBar';
import { Storefront } from './components/Storefront';
import { AdminDashboard } from './components/AdminDashboard';

function getInitialView(): 'storefront' | 'admin' {
  if (typeof window !== 'undefined' && window.location.pathname.startsWith('/admin')) {
    return 'admin';
  }
  return 'storefront';
}

export default function App() {
  const [view, setView] = useState<'storefront' | 'admin'>(getInitialView);

  useEffect(() => {
    const onPopState = () => {
      setView(getInitialView());
    };
    window.addEventListener('popstate', onPopState);
    return () => window.removeEventListener('popstate', onPopState);
  }, []);

  const handleNavigate = (nextView: 'storefront' | 'admin', hash?: string) => {
    const targetPath = nextView === 'admin' ? '/admin' : '/';
    if (window.location.pathname !== targetPath) {
      window.history.pushState({}, '', targetPath);
    }
    setView(nextView);

    if (hash) {
      window.setTimeout(() => {
        document.getElementById(hash)?.scrollIntoView({ behavior: 'smooth' });
      }, 60);
    } else {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen bg-[#F6FAF7] text-[#091710]">
      <TopBar currentView={view} onNavigate={handleNavigate} />
      {view === 'storefront' ? <Storefront /> : <AdminDashboard />}
    </div>
  );
}
