export type ProductCategory =
  | 'DATA DEALS'
  | 'TUNUKIWA DEALS'
  | 'MINUTES DEALS'
  | 'SMS DEALS';

export interface Product {
  id: number;
  slug: string;
  category: ProductCategory;
  name: string;
  validity: string;
  price: number;
  active?: number;
  sort_order: number;
  created_at?: string;
  updated_at?: string;
}

export interface OrderItem {
  id: number;
  product_id: number | null;
  category: ProductCategory;
  product_name: string;
  validity: string;
  unit_price: number;
  quantity: number;
  line_total: number;
}

export type PaymentStatus =
  | 'PENDING'
  | 'STK_SENT'
  | 'PAID'
  | 'FAILED'
  | 'CANCELLED';

export type OrderStatus =
  | 'AWAITING_PAYMENT'
  | 'PENDING_FULFILMENT'
  | 'FULFILLED'
  | 'CANCELLED';

export interface Order {
  id: number;
  orderRef: string;
  recipientPhone: string;
  mpesaPhone: string;
  totalAmount: number;
  paymentStatus: PaymentStatus;
  orderStatus: OrderStatus;
  checkoutRequestId: string | null;
  mpesaReceipt: string | null;
  resultCode: number | null;
  resultDesc: string | null;
  adminNotes: string;
  autoFulfillEnabled: boolean;
  createdAt: string;
  updatedAt: string;
  items: OrderItem[];
}

export interface AdminOrderSummary {
  totalOrders: number;
  paidPendingFulfilment: number;
  fulfilledCount: number;
  totalRevenue: number;
}
