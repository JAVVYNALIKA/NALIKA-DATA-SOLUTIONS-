import 'dotenv/config';
import crypto from 'crypto';
import fs from 'fs';
import path from 'path';
import express from 'express';
import { createServer as createViteServer } from 'vite';

import { db } from './server/db.ts';
import {
  normalizeKenyanPhone,
  isSafaricomPrefix,
  isValidCategory,
} from './server/validators.ts';
import {
  safeCompare,
  hashPassword,
  verifyPassword,
  isEnvAdminConfigured,
  getClaimedAdmin,
  signSession,
  requireAdmin,
  type AdminRequest,
} from './server/auth.ts';
import {
  initiateStkPush,
  queryStkPushStatus,
  DarajaError,
} from './server/daraja.ts';

const PORT = Number(process.env.PORT) || 3000;
const BINGWA_AUTO_FULFILL_ENABLED = process.env.BINGWA_AUTO_FULFILL_ENABLED === 'true';

interface DbOrderRow {
  id: number;
  order_ref: string;
  status_token: string;
  recipient_phone: string;
  mpesa_phone: string;
  total_amount: number;
  payment_status: string;
  order_status: string;
  merchant_request_id: string | null;
  checkout_request_id: string | null;
  mpesa_receipt: string | null;
  result_code: number | null;
  result_desc: string | null;
  admin_notes: string;
  created_at: string;
  updated_at: string;
}

interface DbProductRow {
  id: number;
  slug: string;
  category: string;
  name: string;
  validity: string;
  price: number;
  active: number;
  sort_order: number;
}

function generateOrderRef(): string {
  const random = crypto.randomBytes(3).toString('hex').toUpperCase();
  const timePart = Date.now().toString(36).slice(-4).toUpperCase();
  return `NLK${timePart}${random}`.slice(0, 12);
}

function getOrderWithItems(orderRow: DbOrderRow | undefined) {
  if (!orderRow) return null;
  const items = db
    .prepare(
      `
    SELECT id, product_id, category, product_name, validity, unit_price, quantity, line_total
    FROM order_items
    WHERE order_id = ?
    ORDER BY id ASC
  `
    )
    .all(orderRow.id);

  return {
    id: orderRow.id,
    orderRef: orderRow.order_ref,
    recipientPhone: orderRow.recipient_phone,
    mpesaPhone: orderRow.mpesa_phone,
    totalAmount: orderRow.total_amount,
    paymentStatus: orderRow.payment_status,
    orderStatus: orderRow.order_status,
    checkoutRequestId: orderRow.checkout_request_id,
    mpesaReceipt: orderRow.mpesa_receipt,
    resultCode: orderRow.result_code,
    resultDesc: orderRow.result_desc,
    adminNotes: orderRow.admin_notes || '',
    autoFulfillEnabled: BINGWA_AUTO_FULFILL_ENABLED,
    createdAt: orderRow.created_at,
    updatedAt: orderRow.updated_at,
    items,
  };
}

function applyStkQueryResult(
  order: DbOrderRow,
  result: { ResultCode?: string | number; ResultDesc?: string }
) {
  if (result.ResultCode === undefined || result.ResultCode === null) return;
  const code = Number(result.ResultCode);
  const desc = String(result.ResultDesc || '');

  if (code === 0) {
    db.prepare(
      `
      UPDATE orders
      SET payment_status = 'PAID',
          order_status = CASE WHEN order_status = 'AWAITING_PAYMENT' THEN 'PENDING_FULFILMENT' ELSE order_status END,
          result_code = 0,
          result_desc = ?,
          updated_at = datetime('now')
      WHERE id = ? AND payment_status != 'PAID'
    `
    ).run(desc || 'Payment confirmed', order.id);
  } else if (code === 1032) {
    db.prepare(
      `
      UPDATE orders
      SET payment_status = 'CANCELLED',
          result_code = ?,
          result_desc = ?,
          updated_at = datetime('now')
      WHERE id = ? AND payment_status != 'PAID'
    `
    ).run(code, desc || 'Cancelled by user', order.id);
  } else {
    db.prepare(
      `
      UPDATE orders
      SET payment_status = 'FAILED',
          result_code = ?,
          result_desc = ?,
          updated_at = datetime('now')
      WHERE id = ? AND payment_status != 'PAID'
    `
    ).run(code, desc || 'Payment failed', order.id);
  }
}

async function startServer() {
  const app = express();
  app.set('trust proxy', 1);
  app.use(express.json({ limit: '256kb' }));

  // ==========================================
  // PUBLIC API ROUTES
  // ==========================================

  app.get('/api/health', (_req, res) => {
    const till = (process.env.MPESA_TILL_NUMBER || '9207781').trim();
    const darajaConfigured = Boolean(
      (process.env.MPESA_CONSUMER_KEY || '').trim() &&
        (process.env.MPESA_CONSUMER_SECRET || '').trim() &&
        (process.env.MPESA_PASSKEY || '').trim() &&
        (process.env.MPESA_STORE_SHORTCODE || '').trim() &&
        (process.env.MPESA_CALLBACK_URL || '').trim() &&
        (process.env.MPESA_CALLBACK_SECRET || '').trim()
    );
    res.json({
      ok: true,
      business: 'NALIKA DATA SOLUTIONS',
      tillNumber: till === '174379' ? '9207781' : till,
      customerCare: '0798779718',
      autoFulfillEnabled: BINGWA_AUTO_FULFILL_ENABLED,
      darajaConfigured,
    });
  });

  app.get('/api/products', (_req, res) => {
    const products = db
      .prepare(
        `
      SELECT id, slug, category, name, validity, price, sort_order
      FROM products
      WHERE active = 1
      ORDER BY sort_order ASC, id ASC
    `
      )
      .all();

    res.json({ products });
  });

  // Track order (registered BEFORE :orderRef param routes)
  app.get('/api/orders/track', (req, res) => {
    const orderRef = String(req.query.orderRef || '').trim().toUpperCase();
    const phone = normalizeKenyanPhone(String(req.query.phone || ''));

    if (!orderRef || !phone) {
      return res
        .status(400)
        .json({ error: 'Enter both Order Reference and a matching phone number.' });
    }

    const order = db
      .prepare('SELECT * FROM orders WHERE order_ref = ?')
      .get(orderRef) as DbOrderRow | undefined;

    if (!order || (order.recipient_phone !== phone && order.mpesa_phone !== phone)) {
      return res
        .status(404)
        .json({ error: 'No matching order found for that reference and phone number.' });
    }

    return res.json({ order: getOrderWithItems(order) });
  });

  // Create order with authoritative server-side price calculation
  app.post('/api/orders', (req, res) => {
    try {
      const { items, recipientPhone, mpesaPhone } = req.body || {};

      if (!Array.isArray(items) || items.length === 0) {
        return res.status(400).json({ error: 'Please select at least one offer.' });
      }
      if (items.length > 30) {
        return res.status(400).json({ error: 'Too many line items in a single order.' });
      }

      const normalizedRecipient = normalizeKenyanPhone(recipientPhone);
      if (!normalizedRecipient || !isSafaricomPrefix(normalizedRecipient)) {
        return res.status(400).json({
          error:
            'Enter a valid Safaricom number receiving the offer (e.g. 0712345678 or 0112345678).',
        });
      }

      const normalizedMpesa = normalizeKenyanPhone(mpesaPhone);
      if (!normalizedMpesa) {
        return res.status(400).json({
          error: 'Enter a valid M-Pesa payment number (e.g. 07XXXXXXXX).',
        });
      }

      const qtyByProduct = new Map<number, number>();
      for (const entry of items) {
        const productId = Number(entry?.productId);
        const quantity = Number(entry?.quantity);
        if (!Number.isInteger(productId) || productId <= 0) {
          return res.status(400).json({ error: 'Invalid product ID in order.' });
        }
        if (!Number.isInteger(quantity) || quantity < 1 || quantity > 50) {
          return res
            .status(400)
            .json({ error: 'Quantity must be between 1 and 50 per offer.' });
        }
        qtyByProduct.set(productId, (qtyByProduct.get(productId) || 0) + quantity);
      }

      const getProductStmt = db.prepare(
        'SELECT id, slug, category, name, validity, price, active, sort_order FROM products WHERE id = ?'
      );

      const verifiedItems: Array<{
        product_id: number;
        category: string;
        product_name: string;
        validity: string;
        unit_price: number;
        quantity: number;
        line_total: number;
      }> = [];

      let totalAmount = 0;

      for (const [productId, quantity] of qtyByProduct.entries()) {
        const product = getProductStmt.get(productId) as DbProductRow | undefined;
        if (!product || product.active !== 1) {
          return res
            .status(400)
            .json({ error: 'One of the selected offers is no longer available.' });
        }
        const lineTotal = product.price * quantity;
        totalAmount += lineTotal;
        verifiedItems.push({
          product_id: product.id,
          category: product.category,
          product_name: product.name,
          validity: product.validity,
          unit_price: product.price,
          quantity,
          line_total: lineTotal,
        });
      }

      const orderRef = generateOrderRef();
      const statusToken = crypto.randomBytes(16).toString('hex');

      const createTx = db.transaction(() => {
        const insertOrder = db.prepare(`
          INSERT INTO orders (order_ref, status_token, recipient_phone, mpesa_phone, total_amount, payment_status, order_status)
          VALUES (?, ?, ?, ?, ?, 'PENDING', 'AWAITING_PAYMENT')
        `);
        const result = insertOrder.run(
          orderRef,
          statusToken,
          normalizedRecipient,
          normalizedMpesa,
          totalAmount
        );
        const orderId = Number(result.lastInsertRowid);

        const insertItem = db.prepare(`
          INSERT INTO order_items (order_id, product_id, category, product_name, validity, unit_price, quantity, line_total)
          VALUES (@order_id, @product_id, @category, @product_name, @validity, @unit_price, @quantity, @line_total)
        `);

        for (const item of verifiedItems) {
          insertItem.run({ order_id: orderId, ...item });
        }

        return db
          .prepare('SELECT * FROM orders WHERE id = ?')
          .get(orderId) as DbOrderRow;
      });

      const createdOrder = createTx();
      return res.status(201).json({
        order: getOrderWithItems(createdOrder),
        statusToken,
      });
    } catch (err) {
      console.error('Order creation error:', err);
      return res
        .status(500)
        .json({ error: 'Failed to create order. Please try again.' });
    }
  });

  // Trigger Daraja STK Push
  app.post('/api/orders/:orderRef/stk-push', async (req, res) => {
    try {
      const { orderRef } = req.params;
      const { statusToken } = req.body || {};

      const order = db
        .prepare('SELECT * FROM orders WHERE order_ref = ?')
        .get(orderRef) as DbOrderRow | undefined;

      if (!order || !statusToken || !safeCompare(String(statusToken), order.status_token)) {
        return res.status(404).json({ error: 'Order not found.' });
      }

      if (order.payment_status === 'PAID') {
        return res.json({
          message: 'Order is already paid.',
          order: getOrderWithItems(order),
        });
      }

      const stk = await initiateStkPush({
        mpesaPhone: order.mpesa_phone,
        amount: order.total_amount,
        orderRef: order.order_ref,
      });

      db.prepare(
        `
        UPDATE orders
        SET payment_status = 'STK_SENT',
            merchant_request_id = ?,
            checkout_request_id = ?,
            result_code = NULL,
            result_desc = ?,
            updated_at = datetime('now')
        WHERE id = ?
      `
      ).run(
        stk.MerchantRequestID,
        stk.CheckoutRequestID,
        stk.CustomerMessage || 'STK Push sent to phone',
        order.id
      );

      const updated = db
        .prepare('SELECT * FROM orders WHERE id = ?')
        .get(order.id) as DbOrderRow;

      return res.json({
        message:
          stk.CustomerMessage ||
          'M-Pesa prompt sent to your phone. Enter your M-Pesa PIN to complete payment.',
        order: getOrderWithItems(updated),
      });
    } catch (err) {
      const statusCode = err instanceof DarajaError ? err.statusCode : 500;
      const message =
        err instanceof Error ? err.message : 'Unable to initiate M-Pesa STK Push.';
      return res.status(statusCode).json({ error: message });
    }
  });

  // Poll order & payment status
  app.get('/api/orders/:orderRef/status', (req, res) => {
    const { orderRef } = req.params;
    const token = String(req.query.token || '');

    const order = db
      .prepare('SELECT * FROM orders WHERE order_ref = ?')
      .get(orderRef) as DbOrderRow | undefined;

    if (!order || !token || !safeCompare(token, order.status_token)) {
      return res.status(404).json({ error: 'Order not found.' });
    }

    return res.json({ order: getOrderWithItems(order) });
  });

  // Manual / fallback Daraja STK Query
  app.post('/api/orders/:orderRef/query-payment', async (req, res) => {
    try {
      const { orderRef } = req.params;
      const { statusToken } = req.body || {};

      const order = db
        .prepare('SELECT * FROM orders WHERE order_ref = ?')
        .get(orderRef) as DbOrderRow | undefined;

      if (!order || !statusToken || !safeCompare(String(statusToken), order.status_token)) {
        return res.status(404).json({ error: 'Order not found.' });
      }

      if (order.payment_status === 'PAID') {
        return res.json({ order: getOrderWithItems(order) });
      }
      if (!order.checkout_request_id) {
        return res
          .status(400)
          .json({ error: 'No STK Push request has been sent for this order yet.' });
      }

      const result = await queryStkPushStatus(order.checkout_request_id);
      applyStkQueryResult(order, result);

      const updated = db
        .prepare('SELECT * FROM orders WHERE id = ?')
        .get(order.id) as DbOrderRow;

      return res.json({ order: getOrderWithItems(updated), daraja: result });
    } catch (err) {
      const statusCode = err instanceof DarajaError ? err.statusCode : 500;
      const message =
        err instanceof Error ? err.message : 'Could not verify payment status.';
      return res.status(statusCode).json({ error: message });
    }
  });

  // ==========================================
  // SAFARICOM DARAJA CALLBACK WEBHOOK
  // ==========================================

  app.post('/api/mpesa/callback/:secret', (req, res) => {
    const configuredSecret = (process.env.MPESA_CALLBACK_SECRET || '').trim();
    if (!configuredSecret || !safeCompare(req.params.secret || '', configuredSecret)) {
      return res.status(403).json({ ResultCode: 1, ResultDesc: 'Forbidden' });
    }

    try {
      const stkCallback = req.body?.Body?.stkCallback;
      if (!stkCallback || !stkCallback.CheckoutRequestID) {
        return res.json({ ResultCode: 0, ResultDesc: 'Accepted' });
      }

      const checkoutId = String(stkCallback.CheckoutRequestID);
      const resultCode = Number(stkCallback.ResultCode);
      const resultDesc = String(stkCallback.ResultDesc || '');

      const order = db
        .prepare('SELECT * FROM orders WHERE checkout_request_id = ?')
        .get(checkoutId) as DbOrderRow | undefined;

      if (!order || order.payment_status === 'PAID') {
        return res.json({ ResultCode: 0, ResultDesc: 'Accepted' });
      }

      if (resultCode === 0) {
        const items = Array.isArray(stkCallback.CallbackMetadata?.Item)
          ? stkCallback.CallbackMetadata.Item
          : [];
        const meta: Record<string, unknown> = {};
        for (const entry of items) {
          if (entry?.Name) meta[String(entry.Name)] = entry.Value;
        }

        const paidAmount =
          meta.Amount !== undefined ? Number(meta.Amount) : order.total_amount;
        const receipt = meta.MpesaReceiptNumber
          ? String(meta.MpesaReceiptNumber)
          : null;

        if (paidAmount < order.total_amount) {
          db.prepare(
            `
            UPDATE orders
            SET payment_status = 'FAILED',
                mpesa_receipt = ?,
                result_code = ?,
                result_desc = ?,
                updated_at = datetime('now')
            WHERE id = ?
          `
          ).run(
            receipt,
            resultCode,
            `Paid amount (${paidAmount}) is less than order total (${order.total_amount})`,
            order.id
          );
        } else {
          db.prepare(
            `
            UPDATE orders
            SET payment_status = 'PAID',
                order_status = 'PENDING_FULFILMENT',
                mpesa_receipt = ?,
                result_code = 0,
                result_desc = ?,
                updated_at = datetime('now')
            WHERE id = ?
          `
          ).run(
            receipt,
            resultDesc || 'The service request is processed successfully.',
            order.id
          );
        }
      } else if (resultCode === 1032) {
        db.prepare(
          `
          UPDATE orders
          SET payment_status = 'CANCELLED',
              result_code = ?,
              result_desc = ?,
              updated_at = datetime('now')
          WHERE id = ?
        `
        ).run(resultCode, resultDesc || 'Request cancelled by user', order.id);
      } else {
        db.prepare(
          `
          UPDATE orders
          SET payment_status = 'FAILED',
              result_code = ?,
              result_desc = ?,
              updated_at = datetime('now')
          WHERE id = ?
        `
        ).run(resultCode, resultDesc || 'Payment was not completed', order.id);
      }

      return res.json({ ResultCode: 0, ResultDesc: 'Accepted' });
    } catch (err) {
      console.error('Callback processing error:', err);
      return res.json({ ResultCode: 0, ResultDesc: 'Accepted' });
    }
  });

  // ==========================================
  // ADMIN AUTH & MANAGEMENT ROUTES
  // ==========================================

  app.get('/api/admin/status', (_req, res) => {
    const envConfigured = isEnvAdminConfigured();
    const claimed = getClaimedAdmin();
    res.json({
      needsSetup: !envConfigured && !claimed,
      envConfigured,
    });
  });

  // One-time first-run admin setup when ADMIN_PASSWORD env var is not configured
  app.post('/api/admin/setup', (req, res) => {
    if (isEnvAdminConfigured()) {
      return res.status(403).json({
        error: 'Admin credentials are managed via environment variables.',
      });
    }
    const existing = getClaimedAdmin();
    if (existing) {
      return res.status(409).json({
        error: 'Admin account has already been set up. Please sign in.',
      });
    }

    const { username, password } = req.body || {};
    const cleanUser = String(username || '').trim();
    const cleanPass = String(password || '');

    if (cleanUser.length < 3 || cleanUser.length > 40) {
      return res
        .status(400)
        .json({ error: 'Username must be between 3 and 40 characters.' });
    }
    if (cleanPass.length < 8) {
      return res
        .status(400)
        .json({ error: 'Password must be at least 8 characters.' });
    }

    const passwordHash = hashPassword(cleanPass);
    try {
      db.prepare(
        `
        INSERT INTO admin_credentials (id, username, password_hash)
        VALUES (1, ?, ?)
      `
      ).run(cleanUser, passwordHash);
    } catch {
      return res.status(409).json({ error: 'Admin account already exists.' });
    }

    const token = signSession(cleanUser);
    return res.status(201).json({ ok: true, username: cleanUser, token });
  });

  app.post('/api/admin/login', (req, res) => {
    const { username, password } = req.body || {};
    const inputUser = String(username || '').trim();
    const inputPass = String(password || '');

    if (isEnvAdminConfigured()) {
      const expectedUser = (process.env.ADMIN_USERNAME || 'admin').trim();
      const expectedPass = (process.env.ADMIN_PASSWORD || '').trim();

      if (!safeCompare(inputUser, expectedUser) || !safeCompare(inputPass, expectedPass)) {
        return res.status(401).json({ error: 'Invalid username or password.' });
      }
      const token = signSession(expectedUser);
      return res.json({ ok: true, username: expectedUser, token });
    }

    const claimed = getClaimedAdmin();
    if (!claimed) {
      return res
        .status(409)
        .json({ error: 'Admin account not set up yet. Complete first-run setup.' });
    }

    if (
      !safeCompare(inputUser, claimed.username) ||
      !verifyPassword(inputPass, claimed.password_hash)
    ) {
      return res.status(401).json({ error: 'Invalid username or password.' });
    }

    const token = signSession(claimed.username);
    return res.json({ ok: true, username: claimed.username, token });
  });

  app.get('/api/admin/me', requireAdmin, (req: AdminRequest, res) => {
    res.json({ authenticated: true, username: req.adminUser });
  });

  app.get('/api/admin/products', requireAdmin, (_req, res) => {
    const products = db
      .prepare(
        `
      SELECT id, slug, category, name, validity, price, active, sort_order, created_at, updated_at
      FROM products
      ORDER BY sort_order ASC, id ASC
    `
      )
      .all();
    res.json({ products });
  });

  app.post('/api/admin/products', requireAdmin, (req, res) => {
    const { category, name, validity, price, sort_order, active } = req.body || {};

    if (!isValidCategory(category)) {
      return res.status(400).json({ error: 'Invalid category.' });
    }
    if (!name || !String(name).trim() || !validity || !String(validity).trim()) {
      return res
        .status(400)
        .json({ error: 'Offer name and validity are required.' });
    }
    const numericPrice = Number(price);
    if (!Number.isInteger(numericPrice) || numericPrice <= 0) {
      return res
        .status(400)
        .json({ error: 'Price must be a positive whole number in KSh.' });
    }

    const slugBase = `${category}-${numericPrice}-${String(name).trim()}-${String(validity).trim()}`
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/^-|-$/g, '');
    const slug = `${slugBase}-${crypto.randomBytes(2).toString('hex')}`;

    const result = db
      .prepare(
        `
      INSERT INTO products (slug, category, name, validity, price, active, sort_order)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `
      )
      .run(
        slug,
        category,
        String(name).trim(),
        String(validity).trim(),
        numericPrice,
        active === false ? 0 : 1,
        Number(sort_order) || 100
      );

    const created = db
      .prepare('SELECT * FROM products WHERE id = ?')
      .get(result.lastInsertRowid);
    res.status(201).json({ product: created });
  });

  app.put('/api/admin/products/:id', requireAdmin, (req, res) => {
    const id = Number(req.params.id);
    const existing = db
      .prepare('SELECT * FROM products WHERE id = ?')
      .get(id) as DbProductRow | undefined;
    if (!existing) {
      return res.status(404).json({ error: 'Product not found.' });
    }

    const category = req.body.category ?? existing.category;
    const name =
      req.body.name !== undefined ? String(req.body.name).trim() : existing.name;
    const validity =
      req.body.validity !== undefined
        ? String(req.body.validity).trim()
        : existing.validity;
    const price =
      req.body.price !== undefined ? Number(req.body.price) : existing.price;
    const active =
      req.body.active !== undefined ? (req.body.active ? 1 : 0) : existing.active;
    const sortOrder =
      req.body.sort_order !== undefined
        ? Number(req.body.sort_order)
        : existing.sort_order;

    if (
      !isValidCategory(category) ||
      !name ||
      !validity ||
      !Number.isInteger(price) ||
      price <= 0
    ) {
      return res.status(400).json({ error: 'Invalid product fields.' });
    }

    db.prepare(
      `
      UPDATE products
      SET category = ?, name = ?, validity = ?, price = ?, active = ?, sort_order = ?, updated_at = datetime('now')
      WHERE id = ?
    `
    ).run(category, name, validity, price, active, sortOrder, id);

    const updated = db.prepare('SELECT * FROM products WHERE id = ?').get(id);
    res.json({ product: updated });
  });

  app.delete('/api/admin/products/:id', requireAdmin, (req, res) => {
    const id = Number(req.params.id);
    const info = db.prepare('DELETE FROM products WHERE id = ?').run(id);
    if (info.changes === 0) {
      return res.status(404).json({ error: 'Product not found.' });
    }
    res.json({ ok: true });
  });

  app.get('/api/admin/orders', requireAdmin, (req, res) => {
    const statusFilter = String(req.query.status || '').trim();
    const search = String(req.query.q || '').trim().toLowerCase();

    let rows = db
      .prepare('SELECT * FROM orders ORDER BY id DESC LIMIT 250')
      .all() as DbOrderRow[];

    if (statusFilter && statusFilter !== 'ALL') {
      rows = rows.filter(
        (r) => r.order_status === statusFilter || r.payment_status === statusFilter
      );
    }
    if (search) {
      rows = rows.filter(
        (r) =>
          r.order_ref.toLowerCase().includes(search) ||
          r.recipient_phone.toLowerCase().includes(search) ||
          r.mpesa_phone.toLowerCase().includes(search) ||
          (r.mpesa_receipt || '').toLowerCase().includes(search)
      );
    }

    const orders = rows.map(getOrderWithItems);
    const summary = {
      totalOrders: (
        db.prepare('SELECT COUNT(*) AS c FROM orders').get() as { c: number }
      ).c,
      paidPendingFulfilment: (
        db
          .prepare(
            "SELECT COUNT(*) AS c FROM orders WHERE payment_status = 'PAID' AND order_status = 'PENDING_FULFILMENT'"
          )
          .get() as { c: number }
      ).c,
      fulfilledCount: (
        db
          .prepare("SELECT COUNT(*) AS c FROM orders WHERE order_status = 'FULFILLED'")
          .get() as { c: number }
      ).c,
      totalRevenue: (
        db
          .prepare(
            "SELECT COALESCE(SUM(total_amount), 0) AS s FROM orders WHERE payment_status = 'PAID'"
          )
          .get() as { s: number }
      ).s,
    };

    res.json({ orders, summary });
  });

  app.patch('/api/admin/orders/:id', requireAdmin, (req, res) => {
    const id = Number(req.params.id);
    const order = db
      .prepare('SELECT * FROM orders WHERE id = ?')
      .get(id) as DbOrderRow | undefined;
    if (!order) {
      return res.status(404).json({ error: 'Order not found.' });
    }

    const allowedOrderStatuses = [
      'AWAITING_PAYMENT',
      'PENDING_FULFILMENT',
      'FULFILLED',
      'CANCELLED',
    ];
    const nextOrderStatus = req.body.orderStatus ?? order.order_status;
    const adminNotes =
      req.body.adminNotes !== undefined
        ? String(req.body.adminNotes).slice(0, 500)
        : order.admin_notes;

    if (!allowedOrderStatuses.includes(nextOrderStatus)) {
      return res.status(400).json({ error: 'Invalid order status.' });
    }

    db.prepare(
      `
      UPDATE orders
      SET order_status = ?, admin_notes = ?, updated_at = datetime('now')
      WHERE id = ?
    `
    ).run(nextOrderStatus, adminNotes, id);

    const updated = db
      .prepare('SELECT * FROM orders WHERE id = ?')
      .get(id) as DbOrderRow;
    res.json({ order: getOrderWithItems(updated) });
  });

  app.post('/api/admin/orders/:id/query-payment', requireAdmin, async (req, res) => {
    try {
      const id = Number(req.params.id);
      const order = db
        .prepare('SELECT * FROM orders WHERE id = ?')
        .get(id) as DbOrderRow | undefined;
      if (!order || !order.checkout_request_id) {
        return res
          .status(404)
          .json({ error: 'Order or CheckoutRequestID not found.' });
      }
      const result = await queryStkPushStatus(order.checkout_request_id);
      applyStkQueryResult(order, result);
      const updated = db
        .prepare('SELECT * FROM orders WHERE id = ?')
        .get(id) as DbOrderRow;
      res.json({ order: getOrderWithItems(updated), daraja: result });
    } catch (err) {
      const statusCode = err instanceof DarajaError ? err.statusCode : 500;
      const message = err instanceof Error ? err.message : 'Query failed.';
      res.status(statusCode).json({ error: message });
    }
  });

  // ==========================================
  // VITE DEV MIDDLEWARE OR PRODUCTION STATIC
  // ==========================================

  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      const indexHtml = path.join(distDir, 'index.html');
      if (fs.existsSync(indexHtml)) {
        res.sendFile(indexHtml);
      } else {
        res.status(404).send('Build output not found.');
      }
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`NALIKA DATA SOLUTIONS server running on port ${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
